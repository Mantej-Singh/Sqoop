import re
from zipfile import ZipFile
from datetime import datetime
from bs4 import BeautifulSoup
import requests
#import lxml.html as lh
import pandas as pd
import json
import folium
import lxml.html as lh
import sys
import threading
import numpy as np
from datetime import timedelta
import ctypes
from folium import plugins
from folium.plugins import MarkerCluster
import geopy.distance
import os
from os import path
import glob
import reverse_geocoder as rg 
import pprint
import datetime
from datetime import date
import xlsxwriter
import time
from pathlib import Path
#from matplotlib import afm, cbook, ft2font, rcParams
import sys
import threading
import numpy as np
from datetime import timedelta
import ctypes
from bs4 import BeautifulSoup
import urllib
import folium
from folium import plugins
from folium.features import CustomIcon
from folium.plugins import MarkerCluster
import numpy as np
import pandas as pd
from collections import namedtuple
import pandas as pd
import json
#import folium
#from folium import plugins
#from folium.plugins import MarkerCluster
import geopy.distance
import os
from os import path
import glob
import glob
import reverse_geocoder as rg 
from pandas import ExcelWriter
import numpy as np
import re
from mac_vendor_lookup import MacLookup
import nest_asyncio
import asyncio
import datetime
import math
from flask import Flask, render_template,request, redirect,session,Response,send_file,send_from_directory
app = Flask(__name__)

# Set the secret key to some random bytes. Keep this really secret!
app.secret_key = os.urandom(16)

@app.route('/')
def student():
    author = "Python-Flask"
    name = "User"
    return render_template('index.html', author=author, name=name)

@app.route('/result',methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        #global phone_mdn
        phone_mdn=request.form['phone_mdn']
        session['phone_mdn']=phone_mdn
        platform_id = request.form['platform_id']
        session['platform_id']=platform_id
        print("Platform ",platform_id," is selected",flush=True)
        #session['devices']=url_for(result)
        #session['phone_mdn']=request.form['phone_mdn']
        #phone_mdn=request.args.get('phone_mdn')
        #session['phone_mdn']=phone_mdn
        print (time.asctime(time.localtime())+":",phone_mdn,flush=True)
        POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
        #This URL is the page you actually want to pull down with requests.
        REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
        payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
        with requests.Session() as sessions:
            post = sessions.post(POST_LOGIN_URL, data=payload)
            mdn_info = sessions.get(REQUEST_MDN_INFO)
        try:
            dfs = pd.read_html(mdn_info.content,keep_default_na=False)
            name=dfs[1].iloc[[0]]['Name'][0]
            list_of_devices=[d.replace('MDN:', '') for d in (re.findall(r'(MDN:\d{10})', mdn_info.text))]
            type_of_devices=re.findall(r'(Type:\w{4,6})', mdn_info.text)
            result = {list_of_devices[i]: type_of_devices[i] for i in range(len(list_of_devices))}
            #result = request.formt
            todays_date=date.today().strftime("%Y-%m-%d")
            return render_template("result.html",result = result,phone_mdn=phone_mdn,name=name,todays_date=todays_date)
        except Exception as e:
            print(time.asctime(time.localtime())+":",'\n****No Data Found****',flush=True)
            print(time.asctime(time.localtime())+":",'Try Different Phone Number',flush=True)
            return '''<!-- Add icon library -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <style>
            .btn {{
              background-color: DodgerBlue;
              border: none;
              color: white;
              padding: 12px 30px;
              cursor: pointer;
              font-size: 20px;
            }}

            /* Darker background on mouse-over */
            .btn:hover {{
              background-color: RoyalBlue;
            }}
            </style>
            <head>
            <body>
            <h1>****Error: {}****</h1>
              <h2>Try a different <b>Phone Number</b></h2>
              <br>
              <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
              </head>
            </body>
              '''.format(str(e))


@app.route('/dataframe',methods = ['POST', 'GET'])
def dataframe():
    try:

        if request.method == 'POST':
            phone_mdn=session.get('phone_mdn')
            platform_id=session.get('platform_id')
            #request.form.get('phone_mdn')
            device_mdn=request.form['device_mdn']
            radio_btn = request.form['option']
            print(radio_btn,"selected",flush=True)
            #global output_file,output_dir
            output_file = device_mdn+'_final_findings'
            geo_output_file=device_mdn+'_geofence_findings'
            session['output_file']=output_file
            session['geo_output_file']=geo_output_file
            output_file_xlsx= output_file+ '.xlsx'
            geo_output_file_xlsx= geo_output_file+ '.xlsx'
            output_dir = Path('downloads')
            output_dir.mkdir(parents=True, exist_ok=True)
            #locate_add_detail.to_csv(output_dir/output_file_xlsx,index=False)
            session['output_file_xlsx']=output_file_xlsx
            session['geo_output_file_xlsx']=geo_output_file_xlsx
            if radio_btn == "geofence":
                samplePhoneGizmo_df= pd.DataFrame()
                start_date=datetime.datetime.strptime(request.form['start_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                end_date=datetime.datetime.strptime(request.form['end_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                start_time = time.time()
                #eturn "Page submitted"
                print(time.asctime(time.localtime())+":",'User MDN: '+phone_mdn,'Device MDN: '+device_mdn,'Start Date: '+str(start_date),'End Date: '+end_date,flush=True)
                POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                #This URL is the page you actually want to pull down with requests.
                REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
                payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
                with requests.Session() as sessions:
                    post = sessions.post(POST_LOGIN_URL, data=payload)
                    mdn_info = sessions.get(REQUEST_MDN_INFO)
                dfs = pd.read_html(mdn_info.content,keep_default_na=False)
                for i in range(0,5000):
                    current_page = POST_LOGIN_URL + \
                                    "?platform_id="+platform_id+"&page=logs&phone_mdn=" + phone_mdn + \
                                    "&band_mdn=" + device_mdn + \
                                    "&search=reason%22%3A%22geofence&date_picker_start="+start_date+"&date_picker_end="+end_date+"&hour_picker_end=00&filter%5B%5D=ios_push&pp="+str(i*50)
                    df_query = "pd.read_html(sessions.get('" + current_page + \
                                "').content,keep_default_na=False,header=0)[2]"
                    #breaking the time loop
                    if len(eval(df_query)) == 0:
                        break
                    print(time.asctime(time.localtime())+":",len(eval(df_query)),flush=True)
                    samplePhoneGizmo_df = samplePhoneGizmo_df.append(eval(df_query))
                print(time.asctime(time.localtime())+":",'Out of loop',flush=True)

                print(time.asctime(time.localtime())+":",'Total rows: ',len(samplePhoneGizmo_df),flush=True)
                samplePhoneGizmo_df.to_csv('C:\\Users\\Gizmo-QA\\Downloads\\Austin\\RealTime\\WebSite\\hosted_to edit\\radiobtn\\device_mdn')
                try:
                    geofence_detail=samplePhoneGizmo_df['Detail']
                    geofence_detail=geofence_detail.str.split(' ', expand=True)
                    geofence_detail.drop([geofence_detail.columns[0],geofence_detail.columns[1],geofence_detail.columns[2]],axis=1,inplace=True)
                    #geofence_detail.to_csv('C:\\Users\\Gizmo-QA\\Downloads\\Austin\\RealTime\\WebSite\\hosted_to edit\\radiobtn\\geofence_detail.csv')
                    geofence_detail=geofence_detail.apply(lambda x: ''.join(x.dropna()),axis=1)
                    geofence_detail=(pd.io.json.json_normalize(geofence_detail.apply(json.loads)))
                    #geofence_detail=geofence_detail.join(pd.io.json.json_normalize(geofence_detail[1].apply(json.loads)))
                    #geofence_detail.drop([geofence_detail.columns[0],geofence_detail.columns[1]],axis=1,inplace=True)
                    print('Total rows:',len(geofence_detail),flush=True)
                    geofence_detail=geofence_detail[['CUSTOM_FIELD.data.locate_id','CUSTOM_FIELD.data.time','CUSTOM_FIELD.battery_level','CUSTOM_FIELD.data.location_type','CUSTOM_FIELD.data.accuracy','CUSTOM_FIELD.data.reason','CUSTOM_FIELD.data.gps_latitude','CUSTOM_FIELD.data.gps_longitude','content-available','alert','CUSTOM_FIELD.data.geofence_latitude','CUSTOM_FIELD.data.geofence_longitude','CUSTOM_FIELD.data.geofence_name', 'CUSTOM_FIELD.data.geofence_radius','CUSTOM_FIELD.data.geofence_transition']]
                    geofence_detail.rename(columns={'CUSTOM_FIELD.data.locate_id':'locate_id','CUSTOM_FIELD.data.time':'time','CUSTOM_FIELD.battery_level':'battery_level','CUSTOM_FIELD.data.location_type':'method','CUSTOM_FIELD.data.accuracy':'accuracy','CUSTOM_FIELD.data.reason':'reason','CUSTOM_FIELD.data.gps_latitude':'latitude','CUSTOM_FIELD.data.gps_longitude':'longitude','content-available':'content_available','CUSTOM_FIELD.data.geofence_latitude':'geofence_latitude','CUSTOM_FIELD.data.geofence_longitude':'geofence_longitude','CUSTOM_FIELD.data.geofence_name':'geofence_name', 'CUSTOM_FIELD.data.geofence_radius':'geofence_radius','CUSTOM_FIELD.data.geofence_transition':'geofence_transition'},inplace=True)
                    # In[98]:
                    geofence_detail['latitude'] = geofence_detail['latitude'].astype(float).fillna(0)
                    geofence_detail['longitude'] = geofence_detail['longitude'].astype(float).fillna(0)
                    geofence_detail['geofence_latitude'] = geofence_detail['geofence_latitude'].astype(float).fillna(0)
                    geofence_detail['geofence_longitude'] = geofence_detail['geofence_longitude'].astype(float).fillna(0)
                    geofence_detail['time']=geofence_detail['time'].astype(str).str[:10].astype(np.int64)
                    geofence_detail['time']=pd.to_datetime(geofence_detail['time'],unit='s', errors='coerce')
                    geofence_detail['time']=geofence_detail['time'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                    geofence_detail=geofence_detail.sort_values(by='time').reset_index(drop=True)
                    geofence_detail['time_delta']=geofence_detail.time.diff().fillna(pd.Timedelta(seconds=0))
                    geofence_detail=geofence_detail[['locate_id', 'time', 'time_delta', 'battery_level', 'method','accuracy', 'reason', 'latitude', 'longitude', 'alert',
                     'geofence_latitude', 'geofence_longitude', 'geofence_name', 'geofence_radius', 'geofence_transition']]


                    geofence_detail.rename(columns={'geofence_transition':'gizmo_status'},inplace=True)
                    dict_gizmo_status={4:"Outside", 3: "Inside"}
                    geofence_detail['gizmo_status'] = geofence_detail['gizmo_status'].map(dict_gizmo_status)
                    def fulladdressmode1(lat,lon):
                        if lat !=0:
                            return ([value for key, value in rg.search((lat, lon),mode=1)[0].items()][2] +", "+[value for key, value in rg.search((lat, lon),mode=1)[0].items()][3])
                        elif lat==0 and lon==0:
                            return 'no_location'
                    geofence_detail['address'] = np.vectorize(fulladdressmode1)(geofence_detail['latitude'],geofence_detail['longitude'])
                    geofence_detail=geofence_detail[['locate_id', 'time', 'time_delta', 'battery_level', 'method','accuracy', 'reason', 'latitude', 'longitude','address', 'gizmo_status',
                     'geofence_latitude', 'geofence_longitude', 'geofence_name', 'geofence_radius']]


                    # In[125]:
                    geofence_detail.dropna( how='all',inplace=True)
                    geofence_detail=geofence_detail[geofence_detail.reason=='geofence']
                    basemap = folium.Map(tiles=None,control_scale = True)


                    tile=folium.TileLayer('openstreetmap',name='Detailed').add_to(basemap)
                    tile=folium.TileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',name='Satellite',attr='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community').add_to(basemap)
                    tile=folium.TileLayer('cartodbpositron',name='Light').add_to(basemap)
                    tile=folium.TileLayer('cartodbdark_matter',name='Dark').add_to(basemap)
                    tile=folium.TileLayer('https://1.base.maps.ls.hereapi.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?apiKey=YM7m9CQzx6eUlfezKsVNF9CIHKyY7cWdvem24zDPUxs',name='Here Maps',attr='HERE.com').add_to(basemap)



                    measure_control=plugins.MeasureControl()
                    mouse_position=plugins.MousePosition(position='bottomright',separator=',',empty_string='NaN',prefix='Lat/Long:')

                    #Getting all lat/longs
                    df_latlongs=geofence_detail[geofence_detail.method!='no_location'][['latitude', 'longitude']].values.tolist()


                    htmap = folium.FeatureGroup(name='HeatMap')
                    htmap.add_child(plugins.HeatMap(df_latlongs, radius = 10))


                    # In[139]:


                    list_methods=[]
                    list_methods.append('Inside: '+str(len(geofence_detail[geofence_detail.gizmo_status=='Inside'])))
                    list_methods.append('Outside: '+str(len(geofence_detail[geofence_detail.gizmo_status=='Outside'])))
                    
                    #add Geofence Count
                    geofence_count= 'Show Geofence: '+str(len(geofence_detail.geofence_name.unique()))


                    # In[140]:


                    inside = folium.FeatureGroup(name=list_methods[0],show=False)
                    outside= folium.FeatureGroup(name=list_methods[1],show=False)


                    # In[141]:


                    geofence_bubble = folium.FeatureGroup(name=geofence_count,show=False)


                    # In[142]:


                    minimap = plugins.MiniMap()


                    # In[143]:


                    fullscreen=plugins.Fullscreen(position='topright',title='Expand me',title_cancel='Exit me',force_separate_button=True)


                    # In[144]:


                    df_inside=geofence_detail[geofence_detail.gizmo_status=='Inside'].reset_index()
                    df_outside=geofence_detail[geofence_detail.gizmo_status=='Outside'].reset_index()


                    # In[145]:


                    df_inside_locationlist = df_inside[['latitude', 'longitude']].values.tolist()
                    df_outside_locationlist= df_outside[['latitude', 'longitude']].values.tolist()


                    # In[146]:


                    #Marker:
                    #Inside
                    for point in range(0, len(df_inside_locationlist)):
                        folium.Marker(df_inside_locationlist[point],tooltip=df_inside['geofence_name'][point],icon=folium.Icon(color='blue', icon_color='white', icon='check-circle', angle=0, prefix='fa'),popup="<b>Geofence Name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_inside['geofence_name'][point]),df_inside['method'][point],str(df_inside['time'][point])[:19],df_inside['reason'][point],df_inside['address'][point],df_inside['latitude'][point],df_inside['longitude'][point],df_inside['latitude'][point],df_inside['longitude'][point])).add_to(inside)


                    # In[147]:


                    #Outside
                    for point in range(0, len(df_outside_locationlist)):
                        folium.Marker(df_outside_locationlist[point],tooltip=df_outside['geofence_name'][point],icon=folium.Icon(color='red', icon_color='white', icon='times-circle', angle=0, prefix='fa'),popup="<b>Geofence Name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_outside['geofence_name'][point]),df_outside['method'][point],str(df_outside['time'][point])[:19],df_outside['reason'][point],df_outside['address'][point],df_outside['latitude'][point],df_outside['longitude'][point],df_outside['latitude'][point],df_outside['longitude'][point])).add_to(outside)


                    # In[148]:


                    def avg(data): 
                        return round(sum(data) / len(data),8)


                    # In[149]:


                    print('Geofences are:',geofence_detail.geofence_name.unique().tolist(),flush=True)


                    # In[150]:


                    #BubbleChart Geofence
                    for i in range(len(geofence_detail.geofence_name.unique().tolist())):
                        folium.Circle(location=(avg(geofence_detail.geofence_latitude[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail.geofence_longitude[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),radius=max(geofence_detail.geofence_radius[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),popup="<b>Accuracy: </b>%s<br></br><b>geofence_name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(max(geofence_detail['accuracy'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),str(max(geofence_detail['geofence_name'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),max(geofence_detail['method'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),str(max(geofence_detail['time'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]))[:19],max(geofence_detail['reason'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),max(geofence_detail['address'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['latitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['longitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['latitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['longitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),color='crimson',fill=True,fill_color='crimson').add_to(geofence_bubble)


                    # In[151]:
                    folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(inside).add_child(outside).add_child(geofence_bubble).add_child(minimap).add_child(fullscreen).add_child(measure_control).add_child(mouse_position))
                    basemap.fit_bounds(htmap.get_bounds())
                    basemap.save('downloads/'+'Maps_'+geo_output_file+'.htm')
                    end_time = timedelta(seconds=round(time.time() - start_time))
                    print(time.asctime(time.localtime())+":","Execution took: %s secs (Wall clock time)" % end_time,flush=True)

                    writer = ExcelWriter(output_dir/geo_output_file_xlsx,datetime_format='mmm d yyyy hh:mm:ss AM/PM')
                    geofence_detail.to_excel(writer,sheet_name='GeoFenceData',index=False)

                    workbook  = writer.book
                    worksheet = writer.sheets['GeoFenceData']
                    worksheet.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet.set_column('A:A', 10)
                    worksheet.set_column('B:B', 23)
                    worksheet.set_column('C:C', 12.86)
                    worksheet.set_column('D:D', 14.14)
                    worksheet.set_column('E:E', 9.50)#method
                    worksheet.set_column('F:F', 10)#acuracy
                    worksheet.set_column('G:G', 10.70)
                    worksheet.set_column('H:H', 12)
                    worksheet.set_column('I:I', 12)
                    worksheet.set_column('J:J', 23)
                    worksheet.set_column('K:K', 14)
                    worksheet.set_column('L:L', 19)
                    worksheet.set_column('M:M', 19)
                    worksheet.set_column('N:N', 16.60)
                    worksheet.set_column('O:O', 16.60)

                    worksheet.autofilter('A1:R1')
                    #worksheet.autofilter('A1:R'len(geofence_detail))

                    header_format = workbook.add_format({'bold': True,'text_wrap': False,'valign': 'center','align': 'left','fg_color': '#D7E4BC','border': 1})

                    #writer.save()
                    # Write the column headers with the defined format.
                    for col_num, value in enumerate(geofence_detail.columns.values):
                        worksheet.write(0,col_num, value, header_format)

                    writer.save()



                except Exception as e:
                    print(time.asctime(time.localtime())+":",'\n****Error Thown****',flush=True)
                    print(time.asctime(time.localtime())+":",'--->',str(e),flush=True)
                    try:
                        
                        samplePhoneGizmo_df= pd.DataFrame()
                        start_date=datetime.datetime.strptime(request.form['start_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                        end_date=datetime.datetime.strptime(request.form['end_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                        start_time = time.time()
                        print(time.asctime(time.localtime())+":",'User MDN: '+phone_mdn,'Device MDN: '+device_mdn,'Start Date: '+str(start_date),'End Date: '+end_date,flush=True)
                        POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                        REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
                        payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
                        with requests.Session() as sessions:
                            samplePhoneGizmo_df= pd.DataFrame()
                            post = sessions.post(POST_LOGIN_URL, data=payload)
                            mdn_info = sessions.get(REQUEST_MDN_INFO)
                        dfs = pd.read_html(mdn_info.content,keep_default_na=False)
                        for i in range(0,5000):
                            current_page = POST_LOGIN_URL + \
                                            "?platform_id="+platform_id+"&page=logs&phone_mdn=" + phone_mdn + \
                                            "&band_mdn=" + device_mdn + \
                                            "&search=reason%22%3A%22geofence&date_picker_start="+start_date+"&date_picker_end="+end_date+"&hour_picker_end=00&filter%5B%5D=android_push&filter%5B%5D=ios_push&&pp="+str(i*50)
                            df_query = "pd.read_html(sessions.get('" + current_page + \
                                        "').content,keep_default_na=False,header=0)[2]"
                            #breaking the time loop
                            if len(eval(df_query)) == 0:
                                break
                            print(time.asctime(time.localtime())+":",len(eval(df_query)),flush=True)
                            samplePhoneGizmo_df = samplePhoneGizmo_df.append(eval(df_query))
                        print(time.asctime(time.localtime())+":",'Out of loop',flush=True)
                        geofence_detail=samplePhoneGizmo_df['Detail']

                        #geofence_detail.str.split('\r', expand=True)

                        geofence_detail=geofence_detail.str.split('{', expand=True)

                        geofence_detail.drop([geofence_detail.columns[0]],axis=1,inplace=True)

                        geofence_detail=geofence_detail.reset_index(drop=True)

                        geofence_detail=geofence_detail[[1,2]]
                        geofence_detail['Detail']='{'+ geofence_detail[1].str.cat(geofence_detail[2],sep='{')

                        geofence_detail= geofence_detail['Detail']

                        geofence_detail=geofence_detail.str.split('--------------- Response -----',expand=True)

                        geofence_detail=geofence_detail.join(pd.io.json.json_normalize(geofence_detail[0].apply(json.loads)))

                        geofence_detail.drop([geofence_detail.columns[0],geofence_detail.columns[1]],axis=1,inplace=True)

                        print('Total rows:',len(geofence_detail),flush=True)

                        geofence_detail=geofence_detail[['data.locate_id','data.time','battery_level','data.location_type','data.accuracy','data.reason','data.gps_latitude','data.gps_longitude','data.geofence_latitude','data.geofence_longitude','data.geofence_name', 'data.geofence_radius','data.geofence_transition']]
                        geofence_detail.rename(columns={'data.locate_id':'locate_id','data.time':'time','battery_level':'battery_level','data.location_type':'method','data.accuracy':'accuracy','data.reason':'reason','data.gps_latitude':'latitude','data.gps_longitude':'longitude','data.geofence_latitude':'geofence_latitude','data.geofence_longitude':'geofence_longitude','data.geofence_name':'geofence_name', 'data.geofence_radius':'geofence_radius','data.geofence_transition':'geofence_transition'},inplace=True)

                        geofence_detail['latitude'] = geofence_detail['latitude'].astype(float).fillna(0)
                        geofence_detail['longitude'] = geofence_detail['longitude'].astype(float).fillna(0)
                        geofence_detail['geofence_latitude'] = geofence_detail['geofence_latitude'].astype(float).fillna(0)
                        geofence_detail['geofence_longitude'] = geofence_detail['geofence_longitude'].astype(float).fillna(0)
                        geofence_detail['time']=geofence_detail['time'].astype(str).str[:10].astype(np.int64)
                        geofence_detail['time']=pd.to_datetime(geofence_detail['time'],unit='s', errors='coerce')
                        geofence_detail['time']=geofence_detail['time'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                        geofence_detail=geofence_detail.sort_values(by='time').reset_index(drop=True)
                        geofence_detail['time_delta']=geofence_detail.time.diff().fillna(pd.Timedelta(seconds=0))
                        geofence_detail=geofence_detail[['locate_id', 'time', 'time_delta', 'battery_level', 'method','accuracy', 'reason', 'latitude', 'longitude',
                         'geofence_latitude', 'geofence_longitude', 'geofence_name', 'geofence_radius', 'geofence_transition']]


                        geofence_detail.rename(columns={'geofence_transition':'gizmo_status'},inplace=True)
                        dict_gizmo_status={4:"Outside", 3: "Inside"}
                        geofence_detail['gizmo_status'] = geofence_detail['gizmo_status'].map(dict_gizmo_status)

                        def fulladdressmode1(lat,lon):
                            if lat !=0:
                                return ([value for key, value in rg.search((lat, lon),mode=1)[0].items()][2] +", "+[value for key, value in rg.search((lat, lon),mode=1)[0].items()][3])
                            elif lat==0 and lon==0:
                                return 'no_location'
                        geofence_detail['address'] = np.vectorize(fulladdressmode1)(geofence_detail['latitude'],geofence_detail['longitude'])
                        geofence_detail=geofence_detail[['locate_id', 'time', 'time_delta', 'battery_level', 'method','accuracy', 'reason', 'latitude', 'longitude','address', 'gizmo_status',
                         'geofence_latitude', 'geofence_longitude', 'geofence_name', 'geofence_radius']]


                        # In[125]:
                        geofence_detail.dropna( how='all',inplace=True)
                        geofence_detail=geofence_detail[geofence_detail.reason=='geofence']
                        basemap = folium.Map(tiles=None,control_scale = True)
                        tile=folium.TileLayer('openstreetmap',name='Detailed').add_to(basemap)
                        tile=folium.TileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',name='Satellite',attr='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community').add_to(basemap)
                        tile=folium.TileLayer('cartodbpositron',name='Light').add_to(basemap)
                        tile=folium.TileLayer('cartodbdark_matter',name='Dark').add_to(basemap)
                        tile=folium.TileLayer('https://1.base.maps.ls.hereapi.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?apiKey=YM7m9CQzx6eUlfezKsVNF9CIHKyY7cWdvem24zDPUxs',name='Here Maps',attr='HERE.com').add_to(basemap)



                        measure_control=plugins.MeasureControl()
                        mouse_position=plugins.MousePosition(position='bottomright',separator=',',empty_string='NaN',prefix='Lat/Long:')

                        #Getting all lat/longs
                        df_latlongs=geofence_detail[geofence_detail.method!='no_location'][['latitude', 'longitude']].values.tolist()


                        htmap = folium.FeatureGroup(name='HeatMap')
                        htmap.add_child(plugins.HeatMap(df_latlongs, radius = 10))


                        # In[139]:


                        list_methods=[]
                        list_methods.append('Inside: '+str(len(geofence_detail[geofence_detail.gizmo_status=='Inside'])))
                        list_methods.append('Outside: '+str(len(geofence_detail[geofence_detail.gizmo_status=='Outside'])))

                        #add Geofence Count
                        geofence_count= 'Show Geofence: '+str(len(geofence_detail.geofence_name.unique()))


                        # In[140]:


                        inside = folium.FeatureGroup(name=list_methods[0],show=False)
                        outside= folium.FeatureGroup(name=list_methods[1],show=False)


                        # In[141]:


                        geofence_bubble = folium.FeatureGroup(name=geofence_count,show=False)


                        # In[142]:


                        minimap = plugins.MiniMap()


                        # In[143]:


                        fullscreen=plugins.Fullscreen(position='topright',title='Expand me',title_cancel='Exit me',force_separate_button=True)


                        # In[144]:
                        df_inside=geofence_detail[geofence_detail.gizmo_status=='Inside'].reset_index()
                        df_outside=geofence_detail[geofence_detail.gizmo_status=='Outside'].reset_index()


                        # In[145]:


                        df_inside_locationlist = df_inside[['latitude', 'longitude']].values.tolist()
                        df_outside_locationlist= df_outside[['latitude', 'longitude']].values.tolist()


                        # In[146]:


                        #Marker:
                        #Inside
                        for point in range(0, len(df_inside_locationlist)):
                            folium.Marker(df_inside_locationlist[point],tooltip=df_inside['geofence_name'][point],icon=folium.Icon(color='blue', icon_color='white', icon='check-circle', angle=0, prefix='fa'),popup="<b>Geofence Name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_inside['geofence_name'][point]),df_inside['method'][point],str(df_inside['time'][point])[:19],df_inside['reason'][point],df_inside['address'][point],df_inside['latitude'][point],df_inside['longitude'][point],df_inside['latitude'][point],df_inside['longitude'][point])).add_to(inside)


                        # In[147]:


                        #Outside
                        for point in range(0, len(df_outside_locationlist)):
                            folium.Marker(df_outside_locationlist[point],tooltip=df_outside['geofence_name'][point],icon=folium.Icon(color='red', icon_color='white', icon='times-circle', angle=0, prefix='fa'),popup="<b>Geofence Name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_outside['geofence_name'][point]),df_outside['method'][point],str(df_outside['time'][point])[:19],df_outside['reason'][point],df_outside['address'][point],df_outside['latitude'][point],df_outside['longitude'][point],df_outside['latitude'][point],df_outside['longitude'][point])).add_to(outside)


                        # In[148]:


                        def avg(data): 
                            return round(sum(data) / len(data),8)


                        # In[149]:


                        print('Geofences are:',geofence_detail.geofence_name.unique().tolist(),flush=True)


                        # In[150]:


                        #BubbleChart Geofence
                        for i in range(len(geofence_detail.geofence_name.unique().tolist())):
                            folium.Circle(location=(avg(geofence_detail.geofence_latitude[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail.geofence_longitude[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),radius=max(geofence_detail.geofence_radius[geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),popup="<b>Accuracy: </b>%s<br></br><b>geofence_name: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(max(geofence_detail['accuracy'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),str(max(geofence_detail['geofence_name'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),max(geofence_detail['method'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),str(max(geofence_detail['time'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]))[:19],max(geofence_detail['reason'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),max(geofence_detail['address'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['latitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['longitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['latitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]]),avg(geofence_detail['longitude'][geofence_detail.geofence_name==geofence_detail.geofence_name.unique().tolist()[i]])),color='crimson',fill=True,fill_color='crimson').add_to(geofence_bubble)


                        # In[151]:
                        folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(inside).add_child(outside).add_child(geofence_bubble).add_child(minimap).add_child(fullscreen).add_child(measure_control).add_child(mouse_position))
                        basemap.fit_bounds(htmap.get_bounds())
                        basemap.save('downloads/'+'Maps_'+geo_output_file+'.htm')
                        end_time = timedelta(seconds=round(time.time() - start_time))
                        print(time.asctime(time.localtime())+":","Execution took: %s secs (Wall clock time)" % end_time,flush=True)

                        writer = ExcelWriter(output_dir/geo_output_file_xlsx,datetime_format='mmm d yyyy hh:mm:ss AM/PM')
                        geofence_detail.to_excel(writer,sheet_name='GeoFenceData',index=False)

                        workbook  = writer.book
                        worksheet = writer.sheets['GeoFenceData']
                        worksheet.freeze_panes(1, 0)
                        # Set the column width and format.
                        worksheet.set_column('A:A', 10)
                        worksheet.set_column('B:B', 23)
                        worksheet.set_column('C:C', 12.86)
                        worksheet.set_column('D:D', 14.14)
                        worksheet.set_column('E:E', 9.50)#method
                        worksheet.set_column('F:F', 10)#acuracy
                        worksheet.set_column('G:G', 10.70)
                        worksheet.set_column('H:H', 12)
                        worksheet.set_column('I:I', 12)
                        worksheet.set_column('J:J', 23)
                        worksheet.set_column('K:K', 14)
                        worksheet.set_column('L:L', 19)
                        worksheet.set_column('M:M', 19)
                        worksheet.set_column('N:N', 16.60)
                        worksheet.set_column('O:O', 16.60)

                        worksheet.autofilter('A1:R1')
                        #worksheet.autofilter('A1:R'len(geofence_detail))

                        header_format = workbook.add_format({'bold': True,'text_wrap': False,'valign': 'center','align': 'left','fg_color': '#D7E4BC','border': 1})

                        #writer.save()
                        # Write the column headers with the defined format.
                        for col_num, value in enumerate(geofence_detail.columns.values):
                            worksheet.write(0,col_num, value, header_format)

                        writer.save()
                    except Exception as e:
                                        print(time.asctime(time.localtime())+":",'\n****Error Thown****',flush=True)
                                        print(time.asctime(time.localtime())+":",'--->',str(e),flush=True)
                                        return '''<!-- Add icon library -->
                                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                                        <style>
                                        .btn {{
                                          background-color: DodgerBlue;
                                          border: none;
                                          color: white;
                                          padding: 12px 30px;
                                          cursor: pointer;
                                          font-size: 20px;
                                        }}

                                        /* Darker background on mouse-over */
                                        .btn:hover {{
                                          background-color: RoyalBlue;
                                        }}
                                        </style>
                                        <head>
                                        <body>
                                        <h1>****Error: {}****</h1>
                                          <h2>No Geofence Data Found</h2>
                                          <br>
                                          <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                                          </head>
                                        </body>
                                          '''.format(str(e))

                return'''
                            <!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    </head>
                    <body>

                   <center> 
                    <h1>User MDN: {}</h1>
                    <h2>Gizmo MDN: {}</h2>
                    <br>
                    <h2>Total Records: {}</h2>
                    <h2>Total Geofences: {}</h2>
                      <h2>Total Days: {}</h2>
                      <h2>Total Processing Time: {}</h2>
                    <!-- Download your data->>. <a href="/getCSV">Click me.</a>-->
                    <a href="/getgeoCSV"><button class="btn"><i class="fa fa-file-excel-o"></i> Download (xlsx)</button></a>
                    <!-- <a href="/getMAPS"><button class="btn"><i class="fa fa-map-marker"></i> Download (maps)</button></a>-->
                    <a href="/getgeoZip"><button class="btn"><i class="fa fa-archive"></i> Download Zip (xlsx+Geo_maps)</button></a>
                                <br><br>
                    <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                    <!--<a href="session['devices']"><button class="btn"><i class="fa fa-list-ol"></i> Device</button></a>-->
                    <br><br>
                    <!--<iframe src="../downloads/Maps_9088001475_final_findings.htm" width=100% height=1000></iframe>-->
                    </body></html>'''.format(phone_mdn,device_mdn, len(geofence_detail),geofence_detail.geofence_name.unique().tolist(),str(datetime.datetime.strptime(end_date,"%m-%d-%Y") - datetime.datetime.strptime(start_date,"%m-%d-%Y")),end_time)
            elif radio_btn == "locate_add":
                samplePhoneGizmo_df= pd.DataFrame()
                start_date=datetime.datetime.strptime(request.form['start_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                end_date=datetime.datetime.strptime(request.form['end_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                start_time = time.time()
                print(time.asctime(time.localtime())+":",'User MDN: '+phone_mdn,'Device MDN: '+device_mdn,'Start Date: '+str(start_date),'End Date: '+end_date,flush=True)
                POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                #This URL is the page you actually want to pull down with requests.
                REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
                payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
                with requests.Session() as sessions:
                    post = sessions.post(POST_LOGIN_URL, data=payload)
                    mdn_info = sessions.get(REQUEST_MDN_INFO)
                dfs = pd.read_html(mdn_info.content,keep_default_na=False)
                for i in range(0,5000):
                    current_page = POST_LOGIN_URL + \
                                    "?platform_id="+platform_id+"&page=logs&phone_mdn=" + phone_mdn + \
                                    "&band_mdn=" + device_mdn + \
                                    "&date_picker_start="+start_date+"&date_picker_end="+end_date+"&hour_picker_end=00&filter%5B%5D=%2Fdevice%2Flocate.add&pp="+str(i*50)
                    df_query = "pd.read_html(sessions.get('" + current_page + \
                                "').content,keep_default_na=False,header=0)[2]"
                    #breaking the time loop
                    if len(eval(df_query)) == 0:
                        break
                    print(time.asctime(time.localtime())+":",len(eval(df_query)),flush=True)
                    samplePhoneGizmo_df = samplePhoneGizmo_df.append(eval(df_query))
                print(time.asctime(time.localtime())+":",'Out of loop',flush=True)

                print(time.asctime(time.localtime())+":",'Total rows: ',len(samplePhoneGizmo_df),flush=True)

                try:
                    #global output_file,output_dir
                    output_file = device_mdn+'_final_findings'
                    session['output_file']=output_file
                    output_file_xlsx= output_file+ '.xlsx'
                    output_dir = Path('downloads')
                    output_dir.mkdir(parents=True, exist_ok=True)
                    session['output_file_xlsx']=output_file_xlsx
                    locate_add_detail=samplePhoneGizmo_df['Detail']
                    #samplePhoneGizmo_df.to_csv(output_dir/device_mdn,index=False)
                    ###writer = ExcelWriter(output_dir/device_mdn)
                    ###samplePhoneGizmo_df.to_excel(writer,sheet_name='scraped_dump',index=False)
                    locate_add_detail=locate_add_detail.str.split('--------------- Response -----', expand=True)
                    print('\n Scrapping done. Resetting the index',output_dir/device_mdn,flush=True)
                    locate_add_detail.reset_index(drop=True,inplace=True)
                    deleted_rows=len(locate_add_detail[locate_add_detail[1].str.contains('null')])
                    print(time.asctime(time.localtime())+":",deleted_rows,'rows have no_location reported',flush=True)
                    #print('\n')
                    #locate_add_detail.drop(locate_add_detail.index[locate_add_detail[1].str.contains('null')], inplace=True)
                    locate_add_detail[1]=locate_add_detail[1].str.replace('null','0')
                    locate_add_detail.reset_index(drop=True,inplace=True)


                    locate_add_detail=locate_add_detail.join(pd.io.json.json_normalize(locate_add_detail[0].apply(json.loads)))
                    locate_add_detail=locate_add_detail.join(pd.io.json.json_normalize(locate_add_detail[1].apply(json.loads)))
                    locate_add_detail.drop([locate_add_detail.columns[0],locate_add_detail.columns[1]],axis=1,inplace=True)


                    try:
                        locate_add_detail=locate_add_detail[['time','data.lat','data.long','location_type','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]
                        dummy_wifi_status=0
                        transactionId_status=0

                    except:
                        dummy_wifi_status=1
                        transactionId_status=1
                        print(time.asctime(time.localtime())+":",'[wifi_access_points] was not found in the index',flush=True)
                        print(time.asctime(time.localtime())+":",'adding dummy wifi_access_points',flush=True)
                        locate_add_detail['wifi_access_points']=0
                        locate_add_detail=locate_add_detail[['time','data.lat','data.long','location_type','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]
                        print(time.asctime(time.localtime())+":",'Added!',flush=True)


                    locate_add_detail.dropna( how='all',inplace=True)

                    locate_add_detail['data.lat'] = locate_add_detail['data.lat'].astype(float).fillna(0)
                    locate_add_detail['data.long'] = locate_add_detail['data.long'].astype(float).fillna(0)

                    locate_add_detail['time']=locate_add_detail['time'].astype(str).str[:10].astype(np.int64)
                    locate_add_detail['time']=pd.to_datetime(locate_add_detail['time'],unit='s', errors='coerce')

                    locate_add_detail['time']=locate_add_detail['time'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                    locate_add_detail=locate_add_detail.sort_values(by='time').reset_index(drop=True)
                    locate_add_detail['time_delta']=locate_add_detail.time.diff().fillna(pd.Timedelta(seconds=0))
                    def get_top_signal_strength(wifi_mac):
                        try:
                            if len(wifi_mac)!=1:
                                return sorted([word.replace("'signal_strength': ","") for word in re.findall(r"('signal_strength': -?\d*\.{0,1}\d+)",wifi_mac)])[:5]
                            else:
                                return 0
                        except:
                            return 0

                    def get_ap_count(wifi_mac):
                        try:
                            return len(re.findall(r"('wifi_mac_address':)",wifi_mac))
                        except:
                            return 0



                    def countOccurences(input_str, keyword): 

                        # split the string by spaces in a 
                        a = input_str.replace(":", '').replace("\'", '').replace(",", '').replace("\{", '').replace('{', '').replace('}', '').replace('[', '').replace(']', '').split(" ")

                        # search for pattern in a 
                        count = 0
                        for i in range(0, len(a)): 

                            # if match found increase count  
                            if (keyword == a[i]): 
                               count = count + 1

                        return count

                    keyword ="wifi_mac_address"
                    locate_add_detail['wifi_access_points']=locate_add_detail['wifi_access_points'].fillna(0)
                    locate_add_detail['wifi_access_points']=locate_add_detail['wifi_access_points'].astype(str)
                    locate_add_detail['ap']=locate_add_detail.apply(lambda locate_add_detail: get_ap_count(locate_add_detail['wifi_access_points']),axis=1)
                    locate_add_detail['ap_strength']=locate_add_detail.apply(lambda locate_add_detail: get_top_signal_strength(locate_add_detail['wifi_access_points']),axis=1)

                    #locate_add_detail['ap']=locate_add_detail.apply(lambda locate_add_detail: countOccurences(locate_add_detail['wifi_access_points'],keyword),axis=1)

                    locate_add_detail=locate_add_detail[['time','time_delta','data.lat','data.long','location_type','ap','ap_strength','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]


                    def getdistance(coords_1, coords_2):
                        if coords_1 == (0,0) or coords_2==(0,0):
                            return 0
                        else:
                            return geopy.distance.geodesic(coords_1, coords_2).m

                    delta=[]

                    for i in range(1,len(locate_add_detail.index)):
                        delta.append(getdistance((locate_add_detail['data.lat'][i-1],locate_add_detail['data.long'][i-1]),(locate_add_detail['data.lat'][i],locate_add_detail['data.long'][i])))
                        #print(i-1,i)

                    delta.insert(0,0)

                    locate_add_detail['location_delta']=[round(float(i),2) for i in delta]
                    ##Calculate Velocity 
                    def get_seconds(time_delta):
                        return time_delta.total_seconds()

                    #multiply the speed value by 2.237 to converte Meter/sec into miles/hour
                    locate_add_detail['speed'] = round((locate_add_detail['location_delta']/locate_add_detail['time_delta'].apply(get_seconds))* 2.237,2).fillna(0)

                    ##Mode1 Get Full address
                    def fulladdressmode1(lat,lon):
                        if lat !=0:
                            return ([value for key, value in rg.search((lat, lon),mode=1)[0].items()][2] +", "+[value for key, value in rg.search((lat, lon),mode=1)[0].items()][3])
                        elif lat==0 and lon==0:
                            return 'no_location'
                    #### excluding deta time & delta location

                    locate_add_detail=locate_add_detail.sort_values(by='time',ascending=True).reset_index(drop=True)

                    locate_add_detail.rename(columns={'data.lat':'latitude','data.long':'longitude','location_type':'method','data.accuracy':'accuracy','ap':'ap_count','wifi_access_points':'ap_mac','network_radio_signal_strength':'LTE_dBM','network_lac':'lac','network_cellid':'cellid'},inplace=True)


                    steps=[]
                    for i in range(1,len(locate_add_detail.index)+1):
                        steps.append(i)


                    locate_add_detail['steps']=steps
                    locate_add_detail['address'] = np.vectorize(fulladdressmode1)(locate_add_detail['latitude'],locate_add_detail['longitude'])
                    locate_add_detail=locate_add_detail[['steps','time','time_delta','method','ttf','accuracy','reason','latitude','longitude','location_delta','speed','address','LTE_dBM','lac','cellid','ap_count','ap_strength','ap_mac']]


                    locate_add_detail['time_delta']=locate_add_detail['time_delta'].astype(str)

                    locate_add_detail.time_delta = locate_add_detail.time_delta.str.strip().str.replace('0 days ', '').str.replace('.000000000', '')

                    #print(locate_add_detail)
                    ######New tabs#######

                    gmaps=locate_add_detail[['time','latitude','longitude','method','ap_count','accuracy','ttf']]

                    location_type_summary = locate_add_detail.groupby('method').size().reset_index(name='Total')
                    location_type_summary['Percentage']=round(100*(location_type_summary.Total/locate_add_detail['accuracy'].count()),2)
                    location_type_summary=location_type_summary.sort_values(by='Percentage',ascending=False).reset_index(drop=True)
                    location_type_summary['Percentage']=location_type_summary['Percentage'].apply( lambda x : str(x) + '%')

                    bins = [0, 10, 25, 50, 100,150,200,300,500,1000,np.inf]
                    locate_add_detail['binned']=pd.cut(locate_add_detail['accuracy'], bins)
                    group_binned = locate_add_detail.groupby(['method',pd.cut(locate_add_detail['accuracy'],bins)]).size().unstack().fillna(0)
                    df_group_binned=locate_add_detail.groupby(['method',pd.cut(locate_add_detail['accuracy'],bins,labels=['(0-10)','(10-25)','(25-50)','(50-100)','(100-150)','(150-200)','(200-300)','(300-500)','(500-1000)','(1000-inf)'])]).size().unstack(0).fillna(0).sort_values(by='accuracy')
                    #Austin's WiFi Error temp Fix:
                    print('Strange WIFI Error at:',locate_add_detail.index[(locate_add_detail.method=='WiFi')&(locate_add_detail.address=='no_location')],flush=True)
                    #print(locate_add_detail[1121:1123])
                    locate_add_detail.drop(locate_add_detail.index[(locate_add_detail.method=='WiFi')&(locate_add_detail.address=='no_location')], inplace=True)
                    locate_add_detail.reset_index(drop=True,inplace=True)
                    #Final Save	
                    locate_add_detail=locate_add_detail[['steps','time','time_delta','method','ap_count','ap_strength','ttf','accuracy','reason','latitude','longitude','location_delta','speed','address','LTE_dBM','lac','cellid','ap_mac']]
                    ############################################################################WiFi Logic#######################################################################
                    try:
                        if dummy_wifi_status!=1:
                            
                            print(time.asctime(time.localtime())+":",'Extracting WiFi Mac addresses...',flush=True)
                            df_mac=locate_add_detail.loc[locate_add_detail.ap_count>0, ['ap_count','ap_mac']].reset_index(drop=True)
                            def get_json_list(mylist):
                                return json.loads(mylist.replace("\'", "\""))

                            df_mac['ap_mac']=df_mac.apply(lambda df_mac: get_json_list(df_mac['ap_mac']),axis=1)
                            df_macs=pd.DataFrame()
                            for i in range (0, len(df_mac)):
                                df_macs=df_macs.append(pd.io.json.json_normalize(df_mac['ap_mac'][i]))

                            df_macs['age']=pd.to_datetime(df_macs['age'],unit='ms', errors='coerce')
                            df_macs['age']=df_macs['age'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                            #df_macs[(sorted(df_macs.channel))]
                            df_macs=df_macs.sort_values(by='age').reset_index(drop=True)
                            print(time.asctime(time.localtime())+":","Applying Reverse WiFi Lookup on ",len(df_macs)," records",flush=True)
                            #asyncio.get_event_loop().run_forever()
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            #print(time.asctime(time.localtime())+":",MacLookup().lookup('74:1b:b2:d8:f7:36'),flush=True)
                            #nest_asyncio.apply()
                            #print(time.asctime(time.localtime())+":","TEST2",flush=True)
                            print(time.asctime(time.localtime())+":","Pre-loading the vendor list...",flush=True)
                            mac = MacLookup()
                            mac.load_vendors()
                            def get_mac_vendor(wifi_mac_address):
                                try:
                                    return mac.lookup(wifi_mac_address)
                                except:
                                    return 'Vendor Not Found'

                            df_macs['wifi_vendor'] = np.vectorize(get_mac_vendor)(df_macs['wifi_mac_address'])
                            df_macs.rename(columns={'wifi_mac_address':'wifi_mac_address','age':'time'},inplace=True)
                            #df_macs.head()
                            total_macs=len(df_macs)
                            print("Extracted",total_macs,"WiFi MACs",flush=True)

                            #Grouping Mac Addresses:
                            grouped_macs=df_macs.groupby('wifi_mac_address',as_index=False).agg({"time":['count',min,max,lambda x: (max(x) - min(x))]})
                            grouped_macs.columns = ["_".join(x) for x in grouped_macs.columns.ravel()]
                            grouped_macs=grouped_macs.sort_values(by='time_count', ascending = False).reset_index(drop=True)
                            grouped_macs.rename(columns={'wifi_mac_address_':'wifi_mac_address','time_count':'frequency','time_min':'min_time','time_max':'max_time','time_<lambda_0>':'time_diff','time_<lambda>':'time_diff'},inplace=True)
                            def round_secnds(t):
                                if t.microsecond > 500000:
                                    t = t + datetime.timedelta(seconds=1)
                                return (t.replace(microsecond=0))

                            def zero_miliseconds(t):
                                return (t.replace(microsecond=0))

                            def unique(list1): 

                                # intilize a null list 
                                unique_list = [] 

                                # traverse for all elements 
                                for x in list1: 
                                    # check if exists in unique_list or not 
                                    if x not in unique_list: 
                                        unique_list.append(x) 
                                # print list 
                                for x in unique_list: 
                                    return (x)

                            #Min Lat/long
                            min_latlong=[]
                            for i in range(len(grouped_macs)):
                                min_latlong.append(unique((locate_add_detail.loc[(locate_add_detail['time']==zero_miliseconds(grouped_macs.min_time[i])) & (locate_add_detail['ap_count'] >0 )][['latitude','longitude']].values.tolist())))
                            grouped_macs['min_latlong']=(min_latlong)

                            #Max Lat/Long
                            #%%time
                            max_latlong=[]
                            for i in range(len(grouped_macs)):
                                max_latlong.append(unique(locate_add_detail.loc[(locate_add_detail['time']==round_secnds(grouped_macs.max_time[i]))][['latitude','longitude']].values.tolist()))
                            grouped_macs['max_latlong']=max_latlong
                            grouped_macs.min_latlong=grouped_macs.min_latlong.fillna(0)
                            grouped_macs.max_latlong=grouped_macs.max_latlong.fillna(0)
                            '''
                            def getdistance(coords_1, coords_2):
                                if coords_1 == (0,0) or coords_2==(0,0):
                                    return 0
                                elif coords_1 == [0,0] or coords_2==[0,0]:
                                    return 0
                                elif coords_1 == 0 or coords_2==0:
                                    return 0
                                else:
                                    return geopy.distance.geodesic(coords_1, coords_2).m
                '''

                            def getdistance(coords_1, coords_2):
                                if  coords_1 !=0 and coords_2 !=0:
                                    return geopy.distance.geodesic(coords_1, coords_2).m
                                else:
                                    return 0


                            location_detla=[]
                            for i in range(len(grouped_macs)):
                                location_detla.append(getdistance(grouped_macs.min_latlong[i],grouped_macs.max_latlong[i]))

                            grouped_macs['location_delta']=[round(float(i),2) for i in location_detla]
                            #nest_asyncio.apply()
                            #print("Event loop ready...")
                            #%%time
                            #print("\n\nYO ", len(grouped_macs['time_diff']),flush=True)
                            print(time.asctime(time.localtime())+":","Applying Reverse WiFi Lookup on ",len(grouped_macs)," records",flush=True)
                            grouped_wifi_vendor=[]
                            for i in range(len(grouped_macs)):
                                grouped_wifi_vendor.append(get_mac_vendor(grouped_macs['wifi_mac_address'][i]))

                            
                            grouped_macs['wifi_vendor']= grouped_wifi_vendor
                            grouped_macs['time_diff']=grouped_macs['time_diff'].astype(str)
                            grouped_macs.time_diff = grouped_macs.time_diff.str.strip().str.replace('0 days ', '').str.replace('.000000000', '').str.replace('.000000', '')
                            print(time.asctime(time.localtime())+":",'Extraction Completed!',flush=True)
                        elif dummy_wifi_status==1:
                            df_macs= pd.DataFrame()
                            grouped_macs= pd.DataFrame()
                            total_macs=0
                            
                    except Exception as e:
                        print(time.asctime(time.localtime())+":",'\n****Error****',flush=True)
                        print(time.asctime(time.localtime())+":",str(e),flush=True)
                        return '''<!-- Add icon library -->
                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                            <style>
                            .btn {{
                              background-color: DodgerBlue;
                              border: none;
                              color: white;
                              padding: 12px 30px;
                              cursor: pointer;
                              font-size: 20px;
                            }}

                            /* Darker background on mouse-over */
                            .btn:hover {{
                              background-color: RoyalBlue;
                            }}
                            </style>
                            <head>
                            <body>
                            <h1>****Error: {}****</h1>
                              <h2></b></h2>
                              <br>
                              {}
                              
                              {}
                              <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                              </head>
                            </body>
                              '''.format(str(e),)
                           
                        
                    ############################################################################transactionId Logic#######################################################################        
                    try:
                        if transactionId_status!=1:
                            print('\n',flush=True)
                            print(time.asctime(time.localtime())+":",'Fetching Transaction IDs for above WiFi ...',flush=True)
                            samplePhoneGizmo_df= pd.DataFrame()
                            POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                            REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
                            payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
                            with requests.Session() as sessions:
                                samplePhoneGizmo_df= pd.DataFrame()
                                post = sessions.post(POST_LOGIN_URL, data=payload)
                                mdn_info = sessions.get(REQUEST_MDN_INFO)
                            dfs = pd.read_html(mdn_info.content,keep_default_na=False)
                            for i in range(0,5000):
                                current_page = POST_LOGIN_URL + \
                                                "?platform_id="+platform_id+"&page=logs&phone_mdn=" + phone_mdn + \
                                                "&band_mdn=" + device_mdn + \
                                                "&search=verizon_wifi_gps&date_picker_start="+start_date+"&date_picker_end="+end_date+"&hour_picker_end=00&&pp="+str(i*50)
                                df_query = "pd.read_html(sessions.get('" + current_page + \
                                            "').content,keep_default_na=False,header=0)[2]"
                                #breaking the time loop
                                if len(eval(df_query)) == 0:
                                    break
                                print(time.asctime(time.localtime())+":",len(eval(df_query)),flush=True)
                                samplePhoneGizmo_df = samplePhoneGizmo_df.append(eval(df_query))
                            print(time.asctime(time.localtime())+":",'Out of loop',flush=True)
                            print(time.asctime(time.localtime())+":",'Total rows for trans_ID: ',len(samplePhoneGizmo_df),flush=True)


                            tras_id_detail=samplePhoneGizmo_df[['Time (America/New_York)','Detail']]

                            tras_id_detail.Detail=pd.io.json.json_normalize(tras_id_detail.Detail.str.split('--------------- Response -----',expand=True)[1].apply(json.loads))['svcBody.transactionId']

                            tras_id_detail.rename(columns={'Time (America/New_York)':'time','Detail':'transactionId'},inplace=True)

                            tras_id_detail['time']=pd.to_datetime(tras_id_detail['time'])

                            tras_id_detail=tras_id_detail.sort_values(by='time').reset_index(drop=True)

                            def zero_seconds(t):
                                return (t.replace(second=0))

                            tras_id_detail['time']=tras_id_detail.apply(lambda tras_id_detail: zero_seconds(tras_id_detail['time']),axis=1)

                            #tras_id_detail.groupby('transactionId').agg({'time':'count'}).reset_index()

                            tras_id_detail=tras_id_detail.groupby("time")["transactionId"].agg(lambda column: ", ".join(column)).reset_index()
                        elif transactionId_status==1:
                            tras_id_detail=pd.DataFrame()

                    
                    except Exception as e:
                        print(time.asctime(time.localtime())+":",'\n****No Data Found****',flush=True)
                        print(time.asctime(time.localtime())+":",'Try Different Phone Number',flush=True)
                        return '''<!-- Add icon library -->
                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                            <style>
                            .btn {{
                              background-color: DodgerBlue;
                              border: none;
                              color: white;
                              padding: 12px 30px;
                              cursor: pointer;
                              font-size: 20px;
                            }}

                            /* Darker background on mouse-over */
                            .btn:hover {{
                              background-color: RoyalBlue;
                            }}
                            </style>
                            <head>
                            <body>
                            <h1>****A transactionId Error: {}****</h1>
                              <h2></b></h2>
                              <br>
                              <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                              </head>
                            </body>
                              '''.format(str(e))
                    ########################################################################Export to excel#######################################################################
                    writer = ExcelWriter(output_dir/output_file_xlsx,datetime_format='mmm d yyyy hh:mm:ss AM/PM')
                    locate_add_detail.to_excel(writer,sheet_name='CleanData',index=False)
                    location_type_summary.to_excel(writer,sheet_name='Pivot',index=False)
                    df_group_binned.to_excel(writer,sheet_name='Bins',index=True)
                    tras_id_detail.to_excel(writer,sheet_name='transactionId',index=False)
                    df_macs.to_excel(writer,sheet_name='MAC Vendors',index=False)
                    grouped_macs.to_excel(writer,sheet_name='Grouped MACs',index=False)
                    


                    # Get the xlsxwriter workbook and worksheet objects.
                    workbook  = writer.book
                    worksheet = writer.sheets['CleanData']
                    worksheet.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet.set_column('A:A', 7)
                    worksheet.set_column('B:B', 23)
                    worksheet.set_column('C:C', 11.86)
                    worksheet.set_column('D:D', 10.14)
                    worksheet.set_column('E:E', 10.50)#ap_count
                    worksheet.set_column('F:F', 24)#ap_strength
                    #worksheet.set_column('F:F', 12.33)
                    worksheet.set_column('G:G', 4.70)
                    worksheet.set_column('H:H', 10)
                    worksheet.set_column('I:I', 23)
                    worksheet.set_column('J:J', 12)
                    worksheet.set_column('K:K', 12)
                    worksheet.set_column('L:L', 15)
                    worksheet.set_column('M:M', 7.70)
                    worksheet.set_column('N:N', 23)
                    worksheet.set_column('O:O', 10.30)
                    worksheet.set_column('P:P', 5.30)
                    worksheet.set_column('Q:Q', 8.30)
                    worksheet.set_column('R:R', 20.30)

                    # Set the autofilter.
                    worksheet.autofilter('A1:R1')

                    # Add a format. Light red fill with dark red text.
                    format_red = workbook.add_format({'bg_color': '#FFC7CE','font_color': '#9C0006'})
                    format_red_font = workbook.add_format({'font_color': '#f52727'})
                    format_grey_font = workbook.add_format({'font_color': '#6f7273'})
                    format_megenta_font = workbook.add_format({'font_color': '#9C0006'})
                    format_green = workbook.add_format({'bg_color': '#C6EFCE','font_color': '#006100'})

                    header_format = workbook.add_format({'bold': True,'text_wrap': False,'valign': 'center','align': 'left','fg_color': '#D7E4BC','border': 1})

                    #writer.save()
                    # Write the column headers with the defined format.
                    for col_num, value in enumerate(locate_add_detail.columns.values):
                        worksheet.write(0,col_num, value, header_format)


                    worksheet.conditional_format('H2:H1048576', {'type':'cell','criteria': '>','value':100,'format':format_red})
                    worksheet.conditional_format('H2:H1048576', {'type':'cell','criteria': 'between','minimum':1,'maximum': 15,'format':format_green})

                    worksheet.conditional_format('L2:L1048576', {'type': 'data_bar','bar_solid': True}) 

                    #wifi_cached
                    #worksheet.conditional_format('D2:D1048576', {'type':'text','criteria': 'equal to','value':'Wifi','format':format_grey_font})
                    worksheet.conditional_format('D2:D1048576', {'type':'formula', 'criteria': '=(AND($D2="WiFi", $E2=0))',  'format': format_grey_font})

                    #no_location
                    worksheet.conditional_format('D2:D1048576', {'type':'text','criteria': 'containing','value':'no_location','format':format_red_font})
                    worksheet.conditional_format('N2:N1048576', {'type':'text','criteria': 'containing','value':'no_location','format':format_red_font})

                    #realtime_end
                    worksheet.conditional_format('I2:I1048576', {'type':'text','criteria': 'containing','value':'realtime_end','format':format_red_font})

                    ##Speed greater than 100mph
                    worksheet.conditional_format('M2:M1048576', {'type':'cell','criteria': '>','value':100,'format':format_megenta_font})

                    #worksheet=workbook.add_worksheet('Pivot') 
                    worksheet_pivot = writer.sheets['Pivot']
                    # Set the column width and format.
                    worksheet_pivot.set_column('A:A', 12)
                    worksheet_pivot.set_column('B:B', 5)
                    worksheet_pivot.set_column('C:C', 10)

                    #######################################################################
                    #
                    # Create a Pie chart with rotation of the segments.
                    chart3 = workbook.add_chart({'type': 'pie'})

                    # Configure the series.
                    chart3.add_series({
                        'name': 'Pie sales data',
                        'categories': '=Pivot!$A$2:$A$6',
                        'values':     '=Pivot!$B$2:$B$6',
                        #'data_labels': {'value': True, 'legend_key': True},
                        #'data_labels': {'value': True, 'category': True, 'separator': "\n"},
                        'data_labels': {'percentage': True,'category': True, 'separator': ",",'font': {'bold': True}},
                    })

                    # Add a title.
                    chart3.set_title({'name': '# of Locates from all Methods'})

                    # Change the angle/rotation of the first segment.
                    chart3.set_rotation(90)

                    # Insert the chart into the worksheet_pivot (with an offset).
                    worksheet_pivot.insert_chart('E3', chart3, {'x_offset': 25, 'y_offset': 10})
                    ######################################################################


                    #worksheet=workbook.add_worksheet('Bins') 
                    worksheet_bins = writer.sheets['Bins']
                    # Set the column width and format.
                    worksheet_bins.set_column('A:A', 14)
                    worksheet_bins.set_column('B:B', 5)
                    worksheet_bins.set_column('C:C', 5)
                    worksheet_bins.set_column('D:D', 5)
                    worksheet_bins.set_column('E:E', 5)
                    '''
                    worksheet_bins.insert_image('A12','binned_output1.png')
                    '''

                    '''
                    worksheet_bins.conditional_format('B2:B10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('B2:B10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('C2:C10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('C2:C10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('D2:D10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('D2:D10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('E2:E10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('E2:E10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('F2:F10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('F2:F10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    '''

                    #######################################################################
                    #
                    # Create a stacked chart sub-type.
                    #chart2 = workbook.add_chart({'type': 'column', 'subtype': 'stacked'})
                    chart2 = workbook.add_chart({'type': 'column'})
                    # Configure the first series.
                    chart2.add_series({
                        'name':       '=Bins!$B$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$B$2:$B$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Configure second series.
                    chart2.add_series({
                        'name':       '=Bins!$C$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$C$2:$C$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Configure third series.
                    chart2.add_series({
                        'name':       '=Bins!$D$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$D$2:$D$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Add a chart title and some axis labels.
                    chart2.set_title ({'name': 'Comparison of Different Location Methods'})
                    chart2.set_x_axis({'name': 'Tracker Accuracy'})
                    chart2.set_y_axis({'name': 'Observation Count (#)'})

                    # Set an Excel chart style.
                    #chart2.set_style(35)
                    chart2.set_size({'width': 1120, 'height': 500})

                    # Insert the chart into the worksheet (with an offset).
                    worksheet_bins.insert_chart('G3', chart2, {'x_offset': 25, 'y_offset': 10})
                     #######################################################################

                    worksheet_transactionId = writer.sheets['transactionId']
                    worksheet_transactionId.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet_transactionId.set_column('A:A', 22)
                    worksheet_transactionId.set_column('B:B', 30)
                   
                    # Set the autofilter.
                    worksheet_transactionId.autofilter('A1:B1')
                    for col_num, value in enumerate(tras_id_detail.columns.values):
                        worksheet_transactionId.write(0,col_num, value, header_format)

                    
                    #######################################################################

                    worksheet_vendors = writer.sheets['MAC Vendors']
                    worksheet_vendors.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet_vendors.set_column('A:A', 22)
                    worksheet_vendors.set_column('B:B', 10)
                    worksheet_vendors.set_column('C:C', 22)
                    worksheet_vendors.set_column('D:D', 21)
                    worksheet_vendors.set_column('E:E', 19)
                    worksheet_vendors.set_column('F:F', 42)
                    # Set the autofilter.
                    worksheet_vendors.autofilter('A1:F1')
                    for col_num, value in enumerate(df_macs.columns.values):
                        worksheet_vendors.write(0,col_num, value, header_format)

                    #Vendor Not Found, Red
                    worksheet_vendors.conditional_format('F2:F1048576', {'type':'text','criteria': 'containing','value':'Vendor Not Found','format':format_red_font})


                    worksheet_grouped_macs = writer.sheets['Grouped MACs']
                    worksheet_grouped_macs.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet_grouped_macs.set_column('A:A', 19)
                    worksheet_grouped_macs.set_column('B:B', 12)
                    worksheet_grouped_macs.set_column('C:C', 22)
                    worksheet_grouped_macs.set_column('D:D', 22)
                    worksheet_grouped_macs.set_column('E:E', 11)
                    worksheet_grouped_macs.set_column('F:F', 22)
                    worksheet_grouped_macs.set_column('G:G', 22)
                    worksheet_grouped_macs.set_column('H:H', 15)
                    worksheet_grouped_macs.set_column('I:I', 42)
                    worksheet_grouped_macs.autofilter('A1:I1')
                    for col_num, value in enumerate(grouped_macs.columns.values):
                        worksheet_grouped_macs.write(0,col_num, value, header_format)

                    #Vendor Not Found, Red
                    worksheet_grouped_macs.conditional_format('I2:I1048576', {'type':'text','criteria': 'containing','value':'Vendor Not Found','format':format_red_font})


                    ##Save Excel
                    writer.save()
                    #loop.close()


                    #######################################################################Plot Folium Maps#######################################################################
                    def get_bearing(p1, p2):

                        '''
                        Returns compass bearing from p1 to p2

                        Parameters
                        p1 : namedtuple with lat lon
                        p2 : namedtuple with lat lon

                        Return
                        compass bearing of type float

                        Notes
                        Based on https://gist.github.com/jeromer/2005586
                        '''

                        long_diff = np.radians(p2.lon - p1.lon)

                        lat1 = np.radians(p1.lat)
                        lat2 = np.radians(p2.lat)

                        x = np.sin(long_diff) * np.cos(lat2)
                        y = (np.cos(lat1) * np.sin(lat2) 
                            - (np.sin(lat1) * np.cos(lat2) 
                            * np.cos(long_diff)))
                        bearing = np.degrees(np.arctan2(x, y))

                        # adjusting for compass bearing
                        if bearing < 0:
                            return bearing + 360
                        return bearing

                    def get_arrows(locations, color='blue', size=6, n_arrows=3):

                        '''
                        Get a list of correctly placed and rotated 
                        arrows/markers to be plotted

                        Parameters
                        locations : list of lists of lat lons that represent the 
                                    start and end of the line. 
                                    eg [[41.1132, -96.1993],[41.3810, -95.8021]]
                        arrow_color : default is 'blue'
                        size : default is 6
                        n_arrows : number of arrows to create.  default is 3
                        Return
                        list of arrows/markers
                        '''

                        Point = namedtuple('Point', field_names=['lat', 'lon'])

                        # creating point from our Point named tuple
                        p1 = Point(locations[0][0], locations[0][1])
                        p2 = Point(locations[1][0], locations[1][1])

                        # getting the rotation needed for our marker.  
                        # Subtracting 90 to account for the marker's orientation
                        # of due East(get_bearing returns North)
                        rotation = get_bearing(p1, p2) - 90

                        # get an evenly space list of lats and lons for our arrows
                        # note that I'm discarding the first and last for aesthetics
                        # as I'm using markers to denote the start and end
                        arrow_lats = np.linspace(p1.lat, p2.lat, n_arrows + 2)[1:n_arrows+1]
                        arrow_lons = np.linspace(p1.lon, p2.lon, n_arrows + 2)[1:n_arrows+1]

                        arrows = []

                        #creating each "arrow" and appending them to our arrows list
                        for points in zip(arrow_lats, arrow_lons):
                            arrows.append(folium.RegularPolygonMarker(location=points, 
                                          fill_color=color, number_of_sides=3, 
                                          radius=size, rotation=rotation))
                        return arrows


                    #basemap = folium.Map(location=[locate_add_detail['latitude'].mean(), locate_add_detail['longitude'].mean()], zoom_start=10.4,control_scale = True)
                    basemap = folium.Map(tiles=None,control_scale = True)


                    tile=folium.TileLayer('openstreetmap',name='Detailed').add_to(basemap)
                    tile=folium.TileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',name='Satellite',attr='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community').add_to(basemap)
                    tile=folium.TileLayer('cartodbpositron',name='Light').add_to(basemap)
                    tile=folium.TileLayer('cartodbdark_matter',name='Dark').add_to(basemap)
                    tile=folium.TileLayer('https://1.base.maps.ls.hereapi.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?apiKey=YM7m9CQzx6eUlfezKsVNF9CIHKyY7cWdvem24zDPUxs',name='Here Maps',attr='HERE.com').add_to(basemap)
                    #tile=folium.TileLayer('https://1.base.maps.api.here.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?app_id=O2MDZDEi0MNHfDdiqsrGJZHT307F33ZG&app_code=RG59Cpsd7jKeroBL',name='Here Maps_Isaac',attr='HERE.com').add_to(basemap)

                    


                    measure_control=plugins.MeasureControl()
                    mouse_position=plugins.MousePosition(position='bottomright',separator=',',empty_string='NaN',prefix='Lat/Long:')
                    #Getting all lat/longs
                    df_latlongs=locate_add_detail[locate_add_detail.address!='no_location'][['latitude', 'longitude']].values.tolist()


                    htmap = folium.FeatureGroup(name='HeatMap')
                    htmap.add_child(plugins.HeatMap(df_latlongs, radius = 10))



                    list_methods=[]
                    list_methods.append('MSB: '+str(len(locate_add_detail[locate_add_detail.method=='MSB'])))
                    list_methods.append('WiFi'+': '+str(len(locate_add_detail[(locate_add_detail.ap_count != 0) & (locate_add_detail.method=='WiFi')])))
                    list_methods.append('WiFi_Cached'+': '+str(len(locate_add_detail[(locate_add_detail.ap_count == 0) & ((locate_add_detail.method=='WiFi') | (locate_add_detail.method=='Wifi'))])))
                    list_methods.append('MSA'+': '+str(len(locate_add_detail[locate_add_detail.method=='MSA'])))


                    msb = folium.FeatureGroup(name=list_methods[0],show=False)
                    wifi= folium.FeatureGroup(name=list_methods[1],show=False)
                    wifi_cached=folium.FeatureGroup(name=list_methods[2],show=False)
                    msa = folium.FeatureGroup(name=list_methods[3],show=False)

                    msb_bubble = folium.FeatureGroup(name='AccuracyBubble: MSB',show=False)
                    wifi_bubble = folium.FeatureGroup(name='AccuracyBubble: WiFi',show=False)
                    wifi_cached_bubble=folium.FeatureGroup(name='AccuracyBubble: WiFi_Cached',show=False)
                    msa_bubble = folium.FeatureGroup(name='AccuracyBubble: MSA',show=False)

                    directed_line=folium.FeatureGroup(name='Show directions',show=False)
                    minimap = plugins.MiniMap()
                    fullscreen=plugins.Fullscreen(position='topright',title='Expand me',title_cancel='Exit me',force_separate_button=True)

                    df_msb=locate_add_detail[locate_add_detail.method=='MSB'].reset_index()
                    df_wifi=locate_add_detail[(locate_add_detail.ap_count != 0) & (locate_add_detail.method=='WiFi')].reset_index()
                    df_wifi_cached=locate_add_detail[(locate_add_detail.ap_count == 0) & ((locate_add_detail.method=='WiFi') | (locate_add_detail.method=='Wifi'))].reset_index()
                    df_msa=locate_add_detail[locate_add_detail.method=='MSA'].reset_index()

                    df_msb_locationlist = df_msb[df_msb.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_wifi_locationlist = df_wifi[df_wifi.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_wifi_cached_locationlist = df_wifi_cached[df_wifi_cached.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_msa_locationlist = df_msa[df_msa.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    #df_latlongs=locate_add_detail[['latitude', 'longitude']].values.tolist()

                    #Marker:
                    #MSB
                    for point in range(0, len(df_msb_locationlist)):
                        folium.Marker(df_msb_locationlist[point],tooltip=df_msb['accuracy'][point],icon=folium.Icon(color='blue', icon_color='white', icon='globe', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msb['accuracy'][point]),str(df_msb['ttf'][point]),df_msb['method'][point],str(df_msb['time'][point])[:19],df_msb['reason'][point],df_msb['address'][point],df_msb['latitude'][point],df_msb['longitude'][point],df_msb['latitude'][point],df_msb['longitude'][point])).add_to(msb)

                    #WIFI
                    for point in range(0, len(df_wifi_locationlist)):
                        folium.Marker(df_wifi_locationlist[point],tooltip=df_wifi['accuracy'][point],icon=folium.Icon(color='gray', icon_color='white', icon='wifi', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Signal Strength: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi['accuracy'][point],df_wifi['ttf'][point],df_wifi['method'][point],df_wifi['ap_count'][point],df_wifi['ap_strength'][point],str(df_wifi['time'][point])[:19],df_wifi['reason'][point],df_wifi['address'][point],df_wifi['latitude'][point],df_wifi['longitude'][point],df_wifi['latitude'][point],df_wifi['longitude'][point])).add_to(wifi)

                    #WiFi_Cached
                    for point in range(0, len(df_wifi_cached_locationlist)):
                        folium.Marker(df_wifi_cached_locationlist[point],tooltip=df_wifi_cached['accuracy'][point],icon=folium.Icon(color='lightgray', icon_color='white', icon='wifi', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi_cached['accuracy'][point],df_wifi_cached['ttf'][point],df_wifi_cached['method'][point],df_wifi_cached['ap_count'][point],str(df_wifi_cached['time'][point])[:19],df_wifi_cached['reason'][point],df_wifi_cached['address'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point])).add_to(wifi_cached)

                    #MSA
                    for point in range(0, len(df_msa_locationlist)):
                        folium.Marker(df_msa_locationlist[point],tooltip=df_msa['accuracy'][point],icon=folium.Icon(color='orange', icon_color='white', icon='phone', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msa['accuracy'][point]),str(df_msa['ttf'][point]),df_msa['method'][point],str(df_msa['time'][point])[:19],df_msa['reason'][point],df_msa['address'][point],df_msa['latitude'][point],df_msa['longitude'][point],df_msa['latitude'][point],df_msa['longitude'][point])).add_to(msa)

                    #BubbleChart
                    for point in range(0, len(df_msb_locationlist)):
                        folium.Circle(df_msb_locationlist[point],tooltip=df_msb['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msb['accuracy'][point]),str(df_msb['ttf'][point]),df_msb['method'][point],str(df_msb['time'][point])[:19],df_msb['reason'][point],df_msb['address'][point],df_msb['latitude'][point],df_msb['longitude'][point],df_msb['latitude'][point],df_msb['longitude'][point]),radius=float(df_msb['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(msb_bubble)

                    for point in range(0, len(df_wifi_locationlist)):
                        folium.Circle(df_wifi_locationlist[point],tooltip=df_wifi['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br><b>Signal Strength: </b>%s<br></br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi['accuracy'][point],df_wifi['ttf'][point],df_wifi['method'][point],df_wifi['ap_count'][point],df_wifi['ap_strength'][point],str(df_wifi['time'][point])[:19],df_wifi['reason'][point],df_wifi['address'][point],df_wifi['latitude'][point],df_wifi['longitude'][point],df_wifi['latitude'][point],df_wifi['longitude'][point]),radius=float(df_wifi['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(wifi_bubble)

                    for point in range(0, len(df_wifi_cached_locationlist)):
                        folium.Circle(df_wifi_cached_locationlist[point],tooltip=df_wifi_cached['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi_cached['accuracy'][point],df_wifi_cached['ttf'][point],df_wifi_cached['method'][point],df_wifi_cached['ap_count'][point],str(df_wifi_cached['time'][point])[:19],df_wifi_cached['reason'][point],df_wifi_cached['address'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point]),radius=float(df_wifi_cached['accuracy'][point])*.5,color='crimson',fill=True,fill_color='crimson').add_to(wifi_cached_bubble)

                    for point in range(0, len(df_msa_locationlist)):
                        folium.Circle(df_msa_locationlist[point],tooltip=df_msa['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msa['accuracy'][point]),str(df_msa['ttf'][point]),df_msa['method'][point],str(df_msa['time'][point])[:19],df_msa['reason'][point],df_msa['address'][point],df_msa['latitude'][point],df_msa['longitude'][point],df_msa['latitude'][point],df_msa['longitude'][point]),radius=float(df_msa['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(msa_bubble)

                    #Adding lines
                    for point in range(0, (len(df_latlongs)-1)):
                        folium.PolyLine(locations=[df_latlongs[point],df_latlongs[point+1]], color='orange').add_to(directed_line)



                    #Adding Arrows
                    directcall=[]
                    final_combined_arrows= []
                    for point in range(0, (len(df_latlongs)-1)):
                        directcall.append("get_arrows(locations=[df_latlongs["+str(point)+"],df_latlongs["+str(point+1)+"]], n_arrows=3)")
                        final_combined_arrows.append(eval(directcall[point]))

                    for main in final_combined_arrows:
                        for m in main:
                            (m.add_to(directed_line))


                    #folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(msb).add_child(wifi).add_child(msa).add_child(msb_bubble).add_child(wifi_bubble).add_child(msa_bubble).add_child(minimap))
                    folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(msb).add_child(wifi).add_child(wifi_cached).add_child(msa).add_child(msb_bubble).add_child(wifi_bubble).add_child(wifi_cached_bubble).add_child(msa_bubble).add_child(directed_line).add_child(minimap).add_child(fullscreen).add_child(measure_control).add_child(mouse_position))
                    basemap.fit_bounds(htmap.get_bounds())
                    basemap.save('downloads/'+'Maps_'+output_file+'.htm')
                    end_time = timedelta(seconds=round(time.time() - start_time))
                    print(time.asctime(time.localtime())+":","Execution took: %s secs (Wall clock time)" % end_time,flush=True)
                except Exception as e:
                    print(time.asctime(time.localtime())+":",'\n****Error Thown****',flush=True)
                    print(time.asctime(time.localtime())+":",'--->',str(e),flush=True)
                    return '''<!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    <head>
                    <body>
                    <h1>****Error: {}****</h1>
                      <h2>Check the server logs</h2>
                      <h3>Contact: Mantej Singh (mantej.dhanjal@verizonwireless.com) or Priten Vora (priten.vora@verizonwireless.com)</h3>
                      <br>
                      <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                      </head>
                    </body>
                      '''.format(str(e))


                #return "Page submitted"
                return '''
                            <!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    </head>
                    <body>

                   <center> 
                    <h1>User MDN: {}</h1>
                    <h2>Gizmo MDN: {}</h2>
                    <br>
                    <h2>Total Records: {}</h2>
                    <h2>Total Null Locates: {}</h2>
                    <h2>Total WiFi MACs: {}</h2>
                      <h2>Total Days: {}</h2>
                      <h2>Total Processing Time: {}</h2>
                    <!-- Download your data->>. <a href="/getCSV">Click me.</a>-->
                    <a href="/getCSV"><button class="btn"><i class="fa fa-file-excel-o"></i> Download (xlsx)</button></a>
                    <!-- <a href="/getMAPS"><button class="btn"><i class="fa fa-map-marker"></i> Download (maps)</button></a>-->
                    <a href="/getZip"><button class="btn"><i class="fa fa-archive"></i> Download Zip (xlsx+maps)</button></a>
                                <br><br>
                    <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                    <!--<a href="session['devices']"><button class="btn"><i class="fa fa-list-ol"></i> Device</button></a>-->
                    <br><br>
                    <!--<iframe src="../downloads/Maps_9088001475_final_findings.htm" width=100% height=1000></iframe>-->
                    </body></html>'''.format(phone_mdn,device_mdn, len(locate_add_detail),deleted_rows,total_macs,str(datetime.datetime.strptime(end_date,"%m-%d-%Y") - datetime.datetime.strptime(start_date,"%m-%d-%Y")),end_time)
        
            elif radio_btn == "checksim":
                print("Platform ",platform_id," is selected",flush=True)
                POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                REQUEST_LOGS ="https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/?platform_id="+platform_id+"&page=mdninfo&phone_mdn="+device_mdn+"+&imei=&iccid=&debug_vip_config=&checksimcheck=Check+Sim+State"
                payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}

                with requests.Session() as sessions:
                    post = sessions.post(POST_LOGIN_URL, data=payload)
                    imei_logs=sessions.get(REQUEST_LOGS)
                check_sim_data=BeautifulSoup(imei_logs.text,"lxml").prettify(formatter=None)
                print('Device Details:',flush=True)
                deviceId=re.findall(re.compile("<deviceId>(.+?)</deviceId>"),check_sim_data)[0]
                print('\tDevice Id: ',deviceId,flush=True)
                prodName=re.findall(re.compile("<prodName>(.+?)</prodName>"),check_sim_data)[0].replace(u'\xa0', ' ')
                print('\tProduct Name: ',prodName,flush=True)
                prodType=re.findall(re.compile("<prodType>(.+?)</prodType>"),check_sim_data)[0].replace(u'\xa0', ' ')
                print('\tProduct Type: ',prodType,flush=True)
                mfgCode=re.findall(re.compile("<mfgCode>(.+?)</mfgCode>"),check_sim_data)[0].replace(u'\xa0', ' ')
                print('\tMFG Code: ',mfgCode,flush=True)
                deviceSku=re.findall(re.compile("<deviceSku>(.+?)</deviceSku>"),check_sim_data)[0].replace(u'\xa0', ' ')
                print('\tDevice Sku: ',deviceSku,flush=True)

                print('SIM Details:',flush=True)
                iccId=re.findall(re.compile("<iccId>(.+?)</iccId>"),check_sim_data)[0]
                print('\tICCID: ',iccId,flush=True)
                prodName_sim=re.findall(re.compile("<prodName>(.+?)</prodName>"),check_sim_data)[1].replace(u'\xa0', ' ')
                print('\tProduct Name: ',prodName_sim,flush=True)
                mfgCode_sim=re.findall(re.compile("<mfgCode>(.+?)</mfgCode>"),check_sim_data)[1].replace(u'\xa0', ' ')
                print('\tMFG Code: ',mfgCode_sim,flush=True)
                mtnStatusDescription=re.findall(re.compile("<mtnStatusDescription>(.+?)</mtnStatusDescription>"),check_sim_data)[1].replace(u'\xa0', ' ')
                print('\tProduct Type: ',mtnStatusDescription,flush=True)
                
                return '''
                            <!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    </head>
                    <body>

                    <div align="">
                    <h2>Device Details:</h2>
					<ul>
					  <li><h3>Device Id: {}</h3></li>
					  <li><h3>Product Name: {}</h3></li>
					  <li><h3>Product Type: {}</h3></li>
					  <li><h3>MFG Code: {}</h3></li>
					  <li><h3>Device Sku: {}</h3></li>
					</ul>
                    
                    
                    <h2>SIM Details:</h1>
					<ul>
					<li><h3>ICCID: {}</h3></li>
					<li><h3>Product Name: {}</h3></li>
					<li><h3>MFG Code: {}</h3></li>
					<li><h3>Product Type: {}</h3></li>
					</ul>
                    
                    
					
                    <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                    <br><br>
					</div>
                    <!--<iframe src="../downloads/Maps_9088001475_final_findings.htm" width=100% height=1000></iframe>-->
                    </body></html>'''.format(deviceId,prodName,prodType,mfgCode,deviceSku,iccId,prodName_sim,mfgCode_sim,mtnStatusDescription)
            elif radio_btn == "stationary":
                lat_actual=float(request.form['lat_actual'])
                long_actual=float(request.form['long_actual'])
                samplePhoneGizmo_df= pd.DataFrame()
                start_date=datetime.datetime.strptime(request.form['start_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                end_date=datetime.datetime.strptime(request.form['end_date'], '%Y-%m-%d').strftime("%m-%d-%Y")
                start_time = time.time()
                print(time.asctime(time.localtime())+":",'User MDN: '+phone_mdn,'Device MDN: '+device_mdn,'Start Date: '+str(start_date),'End Date: '+end_date,flush=True)
                POST_LOGIN_URL = 'https://gizmohub-prod-tools.smartcom.com/gizmopal_admin/'
                #This URL is the page you actually want to pull down with requests.
                REQUEST_MDN_INFO = POST_LOGIN_URL + "?platform_id="+platform_id+"&page=mdninfo&phone_mdn=" + phone_mdn
                payload = {'new_login':'mantej.dhanjal@verizonwireless.com', 'new_pass':'Verizon@1'}
                with requests.Session() as sessions:
                    post = sessions.post(POST_LOGIN_URL, data=payload)
                    mdn_info = sessions.get(REQUEST_MDN_INFO)
                dfs = pd.read_html(mdn_info.content,keep_default_na=False)
                for i in range(0,5000):
                    current_page = POST_LOGIN_URL + \
                                    "?platform_id="+platform_id+"&page=logs&phone_mdn=" + phone_mdn + \
                                    "&band_mdn=" + device_mdn + \
                                    "&date_picker_start="+start_date+"&date_picker_end="+end_date+"&hour_picker_end=00&filter%5B%5D=%2Fdevice%2Flocate.add&pp="+str(i*50)
                    df_query = "pd.read_html(sessions.get('" + current_page + \
                                "').content,keep_default_na=False,header=0)[2]"
                    #breaking the time loop
                    if len(eval(df_query)) == 0:
                        break
                    print(time.asctime(time.localtime())+":",len(eval(df_query)),flush=True)
                    samplePhoneGizmo_df = samplePhoneGizmo_df.append(eval(df_query))
                print(time.asctime(time.localtime())+":",'Out of loop',flush=True)

                print(time.asctime(time.localtime())+":",'Total rows: ',len(samplePhoneGizmo_df),flush=True)

                try:
                    #global output_file,output_dir
                    output_file = device_mdn+'_final_findings'
                    session['output_file']=output_file
                    output_file_xlsx= output_file+ '.xlsx'
                    output_dir = Path('downloads')
                    output_dir.mkdir(parents=True, exist_ok=True)
                    session['output_file_xlsx']=output_file_xlsx
                    locate_add_detail=samplePhoneGizmo_df['Detail']
                    #samplePhoneGizmo_df.to_csv(output_dir/device_mdn,index=False)
                    ###writer = ExcelWriter(output_dir/device_mdn)
                    ###samplePhoneGizmo_df.to_excel(writer,sheet_name='scraped_dump',index=False)
                    locate_add_detail=locate_add_detail.str.split('--------------- Response -----', expand=True)
                    print('\n Scrapping done. Resetting the index',output_dir/device_mdn,flush=True)
                    locate_add_detail.reset_index(drop=True,inplace=True)
                    deleted_rows=len(locate_add_detail[locate_add_detail[1].str.contains('null')])
                    print(time.asctime(time.localtime())+":",deleted_rows,'rows have no_location reported',flush=True)
                    #print('\n')
                    #locate_add_detail.drop(locate_add_detail.index[locate_add_detail[1].str.contains('null')], inplace=True)
                    locate_add_detail[1]=locate_add_detail[1].str.replace('null','0')
                    locate_add_detail.reset_index(drop=True,inplace=True)


                    locate_add_detail=locate_add_detail.join(pd.io.json.json_normalize(locate_add_detail[0].apply(json.loads)))
                    locate_add_detail=locate_add_detail.join(pd.io.json.json_normalize(locate_add_detail[1].apply(json.loads)))
                    locate_add_detail.drop([locate_add_detail.columns[0],locate_add_detail.columns[1]],axis=1,inplace=True)


                    try:
                        locate_add_detail=locate_add_detail[['time','data.lat','data.long','location_type','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]
                        dummy_wifi_status=0

                    except:
                        dummy_wifi_status=1
                        print(time.asctime(time.localtime())+":",'[wifi_access_points] was not found in the index',flush=True)
                        print(time.asctime(time.localtime())+":",'adding dummy wifi_access_points',flush=True)
                        locate_add_detail['wifi_access_points']=0
                        locate_add_detail=locate_add_detail[['time','data.lat','data.long','location_type','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]
                        print(time.asctime(time.localtime())+":",'Added!',flush=True)


                    locate_add_detail.dropna( how='all',inplace=True)

                    locate_add_detail['data.lat'] = locate_add_detail['data.lat'].astype(float).fillna(0)
                    locate_add_detail['data.long'] = locate_add_detail['data.long'].astype(float).fillna(0)

                    locate_add_detail['time']=locate_add_detail['time'].astype(str).str[:10].astype(np.int64)
                    locate_add_detail['time']=pd.to_datetime(locate_add_detail['time'],unit='s', errors='coerce')

                    locate_add_detail['time']=locate_add_detail['time'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                    locate_add_detail=locate_add_detail.sort_values(by='time').reset_index(drop=True)
                    locate_add_detail['time_delta']=locate_add_detail.time.diff().fillna(pd.Timedelta(seconds=0))
                    def get_top_signal_strength(wifi_mac):
                        try:
                            if len(wifi_mac)!=1:
                                return sorted([word.replace("'signal_strength': ","") for word in re.findall(r"('signal_strength': -?\d*\.{0,1}\d+)",wifi_mac)])[:5]
                            else:
                                return 0
                        except:
                            return 0

                    def get_ap_count(wifi_mac):
                        try:
                            return len(re.findall(r"('wifi_mac_address':)",wifi_mac))
                        except:
                            return 0



                    def countOccurences(input_str, keyword): 

                        # split the string by spaces in a 
                        a = input_str.replace(":", '').replace("\'", '').replace(",", '').replace("\{", '').replace('{', '').replace('}', '').replace('[', '').replace(']', '').split(" ")

                        # search for pattern in a 
                        count = 0
                        for i in range(0, len(a)): 

                            # if match found increase count  
                            if (keyword == a[i]): 
                               count = count + 1

                        return count

                    keyword ="wifi_mac_address"
                    locate_add_detail['wifi_access_points']=locate_add_detail['wifi_access_points'].fillna(0)
                    locate_add_detail['wifi_access_points']=locate_add_detail['wifi_access_points'].astype(str)
                    locate_add_detail['ap']=locate_add_detail.apply(lambda locate_add_detail: get_ap_count(locate_add_detail['wifi_access_points']),axis=1)
                    locate_add_detail['ap_strength']=locate_add_detail.apply(lambda locate_add_detail: get_top_signal_strength(locate_add_detail['wifi_access_points']),axis=1)

                    #locate_add_detail['ap']=locate_add_detail.apply(lambda locate_add_detail: countOccurences(locate_add_detail['wifi_access_points'],keyword),axis=1)

                    locate_add_detail=locate_add_detail[['time','time_delta','data.lat','data.long','location_type','ap','ap_strength','data.accuracy','network_radio_type','network_radio_signal_strength','reason','ttf','wifi_access_points','network_lac','network_cellid']]


                    def getdistance(coords_1, coords_2):
                        if coords_1 == (0,0) or coords_2==(0,0):
                            return 0
                        else:
                            return geopy.distance.geodesic(coords_1, coords_2).m

                    delta=[]

                    for i in range(1,len(locate_add_detail.index)):
                        delta.append(getdistance((locate_add_detail['data.lat'][i-1],locate_add_detail['data.long'][i-1]),(locate_add_detail['data.lat'][i],locate_add_detail['data.long'][i])))
                        #print(i-1,i)

                    delta.insert(0,0)

                    locate_add_detail['location_delta']=[round(float(i),2) for i in delta]
                    ##Calculate Velocity 
                    def get_seconds(time_delta):
                        return time_delta.total_seconds()

                    #multiply the speed value by 2.237 to converte Meter/sec into miles/hour
                    locate_add_detail['speed'] = round((locate_add_detail['location_delta']/locate_add_detail['time_delta'].apply(get_seconds))* 2.237,2).fillna(0)

                    ##Mode1 Get Full address
                    def fulladdressmode1(lat,lon):
                        if lat !=0:
                            return ([value for key, value in rg.search((lat, lon),mode=1)[0].items()][2] +", "+[value for key, value in rg.search((lat, lon),mode=1)[0].items()][3])
                        elif lat==0 and lon==0:
                            return 'no_location'
                    #### excluding deta time & delta location

                    locate_add_detail=locate_add_detail.sort_values(by='time',ascending=True).reset_index(drop=True)

                    locate_add_detail.rename(columns={'data.lat':'latitude','data.long':'longitude','location_type':'method','data.accuracy':'accuracy','ap':'ap_count','wifi_access_points':'ap_mac','network_radio_signal_strength':'LTE_dBM','network_lac':'lac','network_cellid':'cellid'},inplace=True)


                    steps=[]
                    for i in range(1,len(locate_add_detail.index)+1):
                        steps.append(i)


                    locate_add_detail['steps']=steps
                    locate_add_detail['address'] = np.vectorize(fulladdressmode1)(locate_add_detail['latitude'],locate_add_detail['longitude'])
                    locate_add_detail=locate_add_detail[['steps','time','time_delta','method','ttf','accuracy','reason','latitude','longitude','location_delta','speed','address','LTE_dBM','lac','cellid','ap_count','ap_strength','ap_mac']]


                    locate_add_detail['time_delta']=locate_add_detail['time_delta'].astype(str)

                    locate_add_detail.time_delta = locate_add_detail.time_delta.str.strip().str.replace('0 days ', '').str.replace('.000000000', '')

                    #print(locate_add_detail)
                    ######New tabs#######

                    gmaps=locate_add_detail[['time','latitude','longitude','method','ap_count','accuracy','ttf']]

                    location_type_summary = locate_add_detail.groupby('method').size().reset_index(name='Total')
                    location_type_summary['Percentage']=round(100*(location_type_summary.Total/locate_add_detail['accuracy'].count()),2)
                    location_type_summary=location_type_summary.sort_values(by='Percentage',ascending=False).reset_index(drop=True)
                    location_type_summary['Percentage']=location_type_summary['Percentage'].apply( lambda x : str(x) + '%')

                    bins = [0, 10, 25, 50, 100,150,200,300,500,1000,np.inf]
                    locate_add_detail['binned']=pd.cut(locate_add_detail['accuracy'], bins)
                    group_binned = locate_add_detail.groupby(['method',pd.cut(locate_add_detail['accuracy'],bins)]).size().unstack().fillna(0)
                    df_group_binned=locate_add_detail.groupby(['method',pd.cut(locate_add_detail['accuracy'],bins,labels=['(0-10)','(10-25)','(25-50)','(50-100)','(100-150)','(150-200)','(200-300)','(300-500)','(500-1000)','(1000-inf)'])]).size().unstack(0).fillna(0).sort_values(by='accuracy')
                    #Austin's WiFi Error temp Fix:
                    print('Strange WIFI Error at:',locate_add_detail.index[(locate_add_detail.method=='WiFi')&(locate_add_detail.address=='no_location')],flush=True)
                    #print(locate_add_detail[1121:1123])
                    print('lat_actual type: ',type(lat_actual),flush=True)
                    locate_add_detail.drop(locate_add_detail.index[(locate_add_detail.method=='WiFi')&(locate_add_detail.address=='no_location')], inplace=True)
                    locate_add_detail.reset_index(drop=True,inplace=True)
                    def lat_d_ms(lat_reported):
                        return round(float(lat_actual)-lat_reported,6)*80000

                    def lon_d_ms(lon_reported):
                        return round(float(long_actual)-lon_reported,6)*80000

                    def hypotenuse(lat_d_ms,lon_d_ms):
                        return round(math.hypot(lat_d_ms,lon_d_ms),2)

                    locate_add_detail['lat_delta']=np.vectorize(lat_d_ms)(locate_add_detail['latitude'])
                    locate_add_detail['lon_delta']=np.vectorize(lon_d_ms)(locate_add_detail['longitude'])
                    locate_add_detail['actual_delta']=np.vectorize(hypotenuse)(locate_add_detail['lat_delta'],locate_add_detail['lon_delta'])
                    #Final Save	
                    locate_add_detail=locate_add_detail[['steps','time','time_delta','method','ap_count','ap_strength','reason','latitude','longitude','location_delta','ttf','accuracy','lat_delta','lon_delta','actual_delta','speed','address','LTE_dBM','lac','cellid','ap_mac']]
                    ############################################################################WiFi Logic#######################################################################
                    try:
                        if dummy_wifi_status!=1:
                            
                            print(time.asctime(time.localtime())+":",'Extracting WiFi Mac addresses...',flush=True)
                            df_mac=locate_add_detail.loc[locate_add_detail.ap_count>0, ['ap_count','ap_mac']].reset_index(drop=True)
                            def get_json_list(mylist):
                                return json.loads(mylist.replace("\'", "\""))

                            df_mac['ap_mac']=df_mac.apply(lambda df_mac: get_json_list(df_mac['ap_mac']),axis=1)
                            df_macs=pd.DataFrame()
                            for i in range (0, len(df_mac)):
                                df_macs=df_macs.append(pd.io.json.json_normalize(df_mac['ap_mac'][i]))

                            df_macs['age']=pd.to_datetime(df_macs['age'],unit='ms', errors='coerce')
                            df_macs['age']=df_macs['age'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
                            #df_macs[(sorted(df_macs.channel))]
                            df_macs=df_macs.sort_values(by='age').reset_index(drop=True)
                            print(time.asctime(time.localtime())+":","Applying Reverse WiFi Lookup on ",len(df_macs)," records",flush=True)
                            #asyncio.get_event_loop().run_forever()
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            #print(time.asctime(time.localtime())+":",MacLookup().lookup('74:1b:b2:d8:f7:36'),flush=True)
                            #nest_asyncio.apply()
                            #print(time.asctime(time.localtime())+":","TEST2",flush=True)
                            print(time.asctime(time.localtime())+":","Pre-loading the vendor list...",flush=True)
                            mac = MacLookup()
                            mac.load_vendors()
                            def get_mac_vendor(wifi_mac_address):
                                try:
                                    return mac.lookup(wifi_mac_address)
                                except:
                                    return 'Vendor Not Found'

                            df_macs['wifi_vendor'] = np.vectorize(get_mac_vendor)(df_macs['wifi_mac_address'])
                            df_macs.rename(columns={'wifi_mac_address':'wifi_mac_address','age':'time'},inplace=True)
                            #df_macs.head()
                            total_macs=len(df_macs)
                            print("Extracted",total_macs,"WiFi MACs",flush=True)

                            #Grouping Mac Addresses:
                            grouped_macs=df_macs.groupby('wifi_mac_address',as_index=False).agg({"time":['count',min,max,lambda x: (max(x) - min(x))]})
                            grouped_macs.columns = ["_".join(x) for x in grouped_macs.columns.ravel()]
                            grouped_macs=grouped_macs.sort_values(by='time_count', ascending = False).reset_index(drop=True)
                            grouped_macs.rename(columns={'wifi_mac_address_':'wifi_mac_address','time_count':'frequency','time_min':'min_time','time_max':'max_time','time_<lambda_0>':'time_diff','time_<lambda>':'time_diff'},inplace=True)
                            def round_secnds(t):
                                if t.microsecond > 500000:
                                    t = t + datetime.timedelta(seconds=1)
                                return (t.replace(microsecond=0))

                            def zero_miliseconds(t):
                                return (t.replace(microsecond=0))

                            def unique(list1): 

                                # intilize a null list 
                                unique_list = [] 

                                # traverse for all elements 
                                for x in list1: 
                                    # check if exists in unique_list or not 
                                    if x not in unique_list: 
                                        unique_list.append(x) 
                                # print list 
                                for x in unique_list: 
                                    return (x)

                            #Min Lat/long
                            min_latlong=[]
                            for i in range(len(grouped_macs)):
                                min_latlong.append(unique((locate_add_detail.loc[(locate_add_detail['time']==zero_miliseconds(grouped_macs.min_time[i])) & (locate_add_detail['ap_count'] >0 )][['latitude','longitude']].values.tolist())))
                            grouped_macs['min_latlong']=(min_latlong)

                            #Max Lat/Long
                            #%%time
                            max_latlong=[]
                            for i in range(len(grouped_macs)):
                                max_latlong.append(unique(locate_add_detail.loc[(locate_add_detail['time']==round_secnds(grouped_macs.max_time[i]))][['latitude','longitude']].values.tolist()))
                            grouped_macs['max_latlong']=max_latlong
                            grouped_macs.min_latlong=grouped_macs.min_latlong.fillna(0)
                            grouped_macs.max_latlong=grouped_macs.max_latlong.fillna(0)
                            '''
                            def getdistance(coords_1, coords_2):
                                if coords_1 == (0,0) or coords_2==(0,0):
                                    return 0
                                elif coords_1 == [0,0] or coords_2==[0,0]:
                                    return 0
                                elif coords_1 == 0 or coords_2==0:
                                    return 0
                                else:
                                    return geopy.distance.geodesic(coords_1, coords_2).m
                '''

                            def getdistance(coords_1, coords_2):
                                if  coords_1 !=0 and coords_2 !=0:
                                    return geopy.distance.geodesic(coords_1, coords_2).m
                                else:
                                    return 0


                            location_detla=[]
                            for i in range(len(grouped_macs)):
                                location_detla.append(getdistance(grouped_macs.min_latlong[i],grouped_macs.max_latlong[i]))

                            grouped_macs['location_delta']=[round(float(i),2) for i in location_detla]
                            #nest_asyncio.apply()
                            #print("Event loop ready...")
                            #%%time
                            print(time.asctime(time.localtime())+":","Applying Reverse WiFi Lookup on ",len(grouped_macs)," records",flush=True)
                            grouped_wifi_vendor=[]
                            for i in range(len(grouped_macs)):
                                grouped_wifi_vendor.append(get_mac_vendor(grouped_macs['wifi_mac_address'][i]))

                            grouped_macs['wifi_vendor']= grouped_wifi_vendor
                            grouped_macs['time_diff']=grouped_macs['time_diff'].astype(str)
                            grouped_macs.time_diff = grouped_macs.time_diff.str.strip().str.replace('0 days ', '').str.replace('.000000000', '').str.replace('.000000', '')
                            print(time.asctime(time.localtime())+":",'Extraction Completed!',flush=True)
                        elif dummy_wifi_status==1:
                            df_macs= pd.DataFrame()
                            grouped_macs= pd.DataFrame()
                            total_macs=0
                            
                    except Exception as e:
                        print(time.asctime(time.localtime())+":",'\n****No Data Found****',flush=True)
                        print(time.asctime(time.localtime())+":",'Try Different Phone Number',flush=True)
                        return '''<!-- Add icon library -->
                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                            <style>
                            .btn {{
                              background-color: DodgerBlue;
                              border: none;
                              color: white;
                              padding: 12px 30px;
                              cursor: pointer;
                              font-size: 20px;
                            }}

                            /* Darker background on mouse-over */
                            .btn:hover {{
                              background-color: RoyalBlue;
                            }}
                            </style>
                            <head>
                            <body>
                            <h1>****Error: {}****</h1>
                              <h2></b></h2>
                              <br>
                              <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                              </head>
                            </body>
                              '''.format(str(e))
                           
                        
                            
                    ########################################################################Export to excel#######################################################################
                    writer = ExcelWriter(output_dir/output_file_xlsx,datetime_format='mmm d yyyy hh:mm:ss AM/PM')
                    locate_add_detail.to_excel(writer,sheet_name='CleanData',index=False)
                    location_type_summary.to_excel(writer,sheet_name='Pivot',index=False)
                    df_group_binned.to_excel(writer,sheet_name='Bins',index=True)
                    df_macs.to_excel(writer,sheet_name='MAC Vendors',index=False)
                    grouped_macs.to_excel(writer,sheet_name='Grouped MACs',index=False)


                    # Get the xlsxwriter workbook and worksheet objects.
                    workbook  = writer.book
                    worksheet = writer.sheets['CleanData']
                    worksheet.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet.set_column('A:A', 7)
                    worksheet.set_column('B:B', 23)
                    worksheet.set_column('C:C', 11.86)
                    worksheet.set_column('D:D', 10.14)
                    worksheet.set_column('E:E', 10.50)#ap_count
                    worksheet.set_column('F:F', 24)#ap_strength
                    worksheet.set_column('G:G', 23)#reason
                    worksheet.set_column('H:H', 12)	#lat
                    worksheet.set_column('I:I', 12)#long
                    worksheet.set_column('J:J', 15)#loaction_delta
                    worksheet.set_column('K:K', 4.70)#ttf
                    worksheet.set_column('L:L', 10)#accuracy
                    worksheet.set_column('M:M', 10)
                    worksheet.set_column('N:N', 10)
                    worksheet.set_column('O:O', 10)
                    worksheet.set_column('P:P', 7.70)#speed
                    worksheet.set_column('Q:Q', 23)#add
                    worksheet.set_column('R:R', 10.30)#lte
                    worksheet.set_column('S:S', 5.30)#lac
                    worksheet.set_column('T:T', 8.30)#cellid
                    worksheet.set_column('U:U', 20.30)#ap_mac

                    # Set the autofilter.
                    worksheet.autofilter('A1:R1')

                    # Add a format. Light red fill with dark red text.
                    format_red = workbook.add_format({'bg_color': '#FFC7CE','font_color': '#9C0006'})
                    format_red_font = workbook.add_format({'font_color': '#f52727'})
                    format_grey_font = workbook.add_format({'font_color': '#6f7273'})
                    format_megenta_font = workbook.add_format({'font_color': '#9C0006'})
                    format_green = workbook.add_format({'bg_color': '#C6EFCE','font_color': '#006100'})

                    header_format = workbook.add_format({'bold': True,'text_wrap': False,'valign': 'center','align': 'left','fg_color': '#D7E4BC','border': 1})

                    #writer.save()
                    # Write the column headers with the defined format.
                    for col_num, value in enumerate(locate_add_detail.columns.values):
                        worksheet.write(0,col_num, value, header_format)


                    worksheet.conditional_format('L2:L1048576', {'type':'cell','criteria': '>','value':100,'format':format_red})
                    worksheet.conditional_format('L2:L1048576', {'type':'cell','criteria': 'between','minimum':1,'maximum': 15,'format':format_green})

                    worksheet.conditional_format('J2:J1048576', {'type': 'data_bar','bar_solid': True})
                    worksheet.conditional_format('O2:O1048576', {'type': 'data_bar','bar_solid': True})

                    #wifi_cached
                    #worksheet.conditional_format('D2:D1048576', {'type':'text','criteria': 'equal to','value':'Wifi','format':format_grey_font})
                    worksheet.conditional_format('D2:D1048576', {'type':'formula', 'criteria': '=(AND($D2="WiFi", $E2=0))',  'format': format_grey_font})

                    #no_location
                    worksheet.conditional_format('D2:D1048576', {'type':'text','criteria': 'containing','value':'no_location','format':format_red_font})
                    worksheet.conditional_format('Q2:Q1048576', {'type':'text','criteria': 'containing','value':'no_location','format':format_red_font})

                    #realtime_end
                    worksheet.conditional_format('G2:G1048576', {'type':'text','criteria': 'containing','value':'realtime_end','format':format_red_font})

                    ##Speed greater than 100mph
                    worksheet.conditional_format('P2:P1048576', {'type':'cell','criteria': '>','value':100,'format':format_megenta_font})

                    #worksheet=workbook.add_worksheet('Pivot') 
                    worksheet_pivot = writer.sheets['Pivot']
                    # Set the column width and format.
                    worksheet_pivot.set_column('A:A', 12)
                    worksheet_pivot.set_column('B:B', 5)
                    worksheet_pivot.set_column('C:C', 10)

                    #######################################################################
                    #
                    # Create a Pie chart with rotation of the segments.
                    chart3 = workbook.add_chart({'type': 'pie'})

                    # Configure the series.
                    chart3.add_series({
                        'name': 'Pie sales data',
                        'categories': '=Pivot!$A$2:$A$6',
                        'values':     '=Pivot!$B$2:$B$6',
                        #'data_labels': {'value': True, 'legend_key': True},
                        #'data_labels': {'value': True, 'category': True, 'separator': "\n"},
                        'data_labels': {'percentage': True,'category': True, 'separator': ",",'font': {'bold': True}},
                    })

                    # Add a title.
                    chart3.set_title({'name': '# of Locates from all Methods'})

                    # Change the angle/rotation of the first segment.
                    chart3.set_rotation(90)

                    # Insert the chart into the worksheet_pivot (with an offset).
                    worksheet_pivot.insert_chart('E3', chart3, {'x_offset': 25, 'y_offset': 10})
                    ######################################################################


                    #worksheet=workbook.add_worksheet('Bins') 
                    worksheet_bins = writer.sheets['Bins']
                    # Set the column width and format.
                    worksheet_bins.set_column('A:A', 14)
                    worksheet_bins.set_column('B:B', 5)
                    worksheet_bins.set_column('C:C', 5)
                    worksheet_bins.set_column('D:D', 5)
                    worksheet_bins.set_column('E:E', 5)
                    '''
                    worksheet_bins.insert_image('A12','binned_output1.png')
                    '''

                    '''
                    worksheet_bins.conditional_format('B2:B10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('B2:B10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('C2:C10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('C2:C10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('D2:D10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('D2:D10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('E2:E10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('E2:E10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    worksheet_bins.conditional_format('F2:F10', {'type':'cell','criteria': '>','value':100,'format':format_green})
                    worksheet_bins.conditional_format('F2:F10', {'type':'cell','criteria': 'between','minimum':0,'maximum': 10,'format':format_red})
                    '''

                    #######################################################################
                    #
                    # Create a stacked chart sub-type.
                    #chart2 = workbook.add_chart({'type': 'column', 'subtype': 'stacked'})
                    chart2 = workbook.add_chart({'type': 'column'})
                    # Configure the first series.
                    chart2.add_series({
                        'name':       '=Bins!$B$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$B$2:$B$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Configure second series.
                    chart2.add_series({
                        'name':       '=Bins!$C$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$C$2:$C$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Configure third series.
                    chart2.add_series({
                        'name':       '=Bins!$D$1',
                        'categories': '=Bins!$A$2:$A$10',
                        'values':     '=Bins!$D$2:$D$10',
                        'data_labels': {'value': True,'font': {'bold': True}},
                    })
                    # Add a chart title and some axis labels.
                    chart2.set_title ({'name': 'Comparison of Different Location Methods'})
                    chart2.set_x_axis({'name': 'Tracker Accuracy'})
                    chart2.set_y_axis({'name': 'Observation Count (#)'})

                    # Set an Excel chart style.
                    #chart2.set_style(35)
                    chart2.set_size({'width': 1120, 'height': 500})

                    # Insert the chart into the worksheet (with an offset).
                    worksheet_bins.insert_chart('G3', chart2, {'x_offset': 25, 'y_offset': 10})
                    #######################################################################

                    worksheet_vendors = writer.sheets['MAC Vendors']
                    worksheet_vendors.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet_vendors.set_column('A:A', 22)
                    worksheet_vendors.set_column('B:B', 10)
                    worksheet_vendors.set_column('C:C', 22)
                    worksheet_vendors.set_column('D:D', 21)
                    worksheet_vendors.set_column('E:E', 19)
                    worksheet_vendors.set_column('F:F', 42)
                    # Set the autofilter.
                    worksheet_vendors.autofilter('A1:F1')
                    for col_num, value in enumerate(df_macs.columns.values):
                        worksheet_vendors.write(0,col_num, value, header_format)

                    #Vendor Not Found, Red
                    worksheet_vendors.conditional_format('F2:F1048576', {'type':'text','criteria': 'containing','value':'Vendor Not Found','format':format_red_font})


                    worksheet_grouped_macs = writer.sheets['Grouped MACs']
                    worksheet_grouped_macs.freeze_panes(1, 0)
                    # Set the column width and format.
                    worksheet_grouped_macs.set_column('A:A', 19)
                    worksheet_grouped_macs.set_column('B:B', 12)
                    worksheet_grouped_macs.set_column('C:C', 22)
                    worksheet_grouped_macs.set_column('D:D', 22)
                    worksheet_grouped_macs.set_column('E:E', 11)
                    worksheet_grouped_macs.set_column('F:F', 22)
                    worksheet_grouped_macs.set_column('G:G', 22)
                    worksheet_grouped_macs.set_column('H:H', 15)
                    worksheet_grouped_macs.set_column('I:I', 42)
                    worksheet_grouped_macs.autofilter('A1:I1')
                    for col_num, value in enumerate(grouped_macs.columns.values):
                        worksheet_grouped_macs.write(0,col_num, value, header_format)

                    #Vendor Not Found, Red
                    worksheet_grouped_macs.conditional_format('I2:I1048576', {'type':'text','criteria': 'containing','value':'Vendor Not Found','format':format_red_font})


                    ##Save Excel
                    writer.save()
                    #loop.close()


                    #######################################################################Plot Folium Maps#######################################################################
                    def get_bearing(p1, p2):

                        '''
                        Returns compass bearing from p1 to p2

                        Parameters
                        p1 : namedtuple with lat lon
                        p2 : namedtuple with lat lon

                        Return
                        compass bearing of type float

                        Notes
                        Based on https://gist.github.com/jeromer/2005586
                        '''

                        long_diff = np.radians(p2.lon - p1.lon)

                        lat1 = np.radians(p1.lat)
                        lat2 = np.radians(p2.lat)

                        x = np.sin(long_diff) * np.cos(lat2)
                        y = (np.cos(lat1) * np.sin(lat2) 
                            - (np.sin(lat1) * np.cos(lat2) 
                            * np.cos(long_diff)))
                        bearing = np.degrees(np.arctan2(x, y))

                        # adjusting for compass bearing
                        if bearing < 0:
                            return bearing + 360
                        return bearing

                    def get_arrows(locations, color='blue', size=6, n_arrows=3):

                        '''
                        Get a list of correctly placed and rotated 
                        arrows/markers to be plotted

                        Parameters
                        locations : list of lists of lat lons that represent the 
                                    start and end of the line. 
                                    eg [[41.1132, -96.1993],[41.3810, -95.8021]]
                        arrow_color : default is 'blue'
                        size : default is 6
                        n_arrows : number of arrows to create.  default is 3
                        Return
                        list of arrows/markers
                        '''

                        Point = namedtuple('Point', field_names=['lat', 'lon'])

                        # creating point from our Point named tuple
                        p1 = Point(locations[0][0], locations[0][1])
                        p2 = Point(locations[1][0], locations[1][1])

                        # getting the rotation needed for our marker.  
                        # Subtracting 90 to account for the marker's orientation
                        # of due East(get_bearing returns North)
                        rotation = get_bearing(p1, p2) - 90

                        # get an evenly space list of lats and lons for our arrows
                        # note that I'm discarding the first and last for aesthetics
                        # as I'm using markers to denote the start and end
                        arrow_lats = np.linspace(p1.lat, p2.lat, n_arrows + 2)[1:n_arrows+1]
                        arrow_lons = np.linspace(p1.lon, p2.lon, n_arrows + 2)[1:n_arrows+1]

                        arrows = []

                        #creating each "arrow" and appending them to our arrows list
                        for points in zip(arrow_lats, arrow_lons):
                            arrows.append(folium.RegularPolygonMarker(location=points, 
                                          fill_color=color, number_of_sides=3, 
                                          radius=size, rotation=rotation))
                        return arrows


                    #basemap = folium.Map(location=[locate_add_detail['latitude'].mean(), locate_add_detail['longitude'].mean()], zoom_start=10.4,control_scale = True)
                    basemap = folium.Map(tiles=None,control_scale = True)


                    tile=folium.TileLayer('openstreetmap',name='Detailed').add_to(basemap)
                    tile=folium.TileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',name='Satellite',attr='Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community').add_to(basemap)
                    tile=folium.TileLayer('cartodbpositron',name='Light').add_to(basemap)
                    tile=folium.TileLayer('cartodbdark_matter',name='Dark').add_to(basemap)
                    tile=folium.TileLayer('https://1.base.maps.ls.hereapi.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?apiKey=YM7m9CQzx6eUlfezKsVNF9CIHKyY7cWdvem24zDPUxs',name='Here Maps',attr='HERE.com').add_to(basemap)
                    


                    measure_control=plugins.MeasureControl()
                    mouse_position=plugins.MousePosition(position='bottomright',separator=',',empty_string='NaN',prefix='Lat/Long:')
                    #Getting all lat/longs
                    df_latlongs=locate_add_detail[locate_add_detail.address!='no_location'][['latitude', 'longitude']].values.tolist()


                    htmap = folium.FeatureGroup(name='HeatMap')
                    htmap.add_child(plugins.HeatMap(df_latlongs, radius = 10))



                    list_methods=[]
                    list_methods.append('MSB: '+str(len(locate_add_detail[locate_add_detail.method=='MSB'])))
                    list_methods.append('WiFi'+': '+str(len(locate_add_detail[(locate_add_detail.ap_count != 0) & (locate_add_detail.method=='WiFi')])))
                    list_methods.append('WiFi_Cached'+': '+str(len(locate_add_detail[(locate_add_detail.ap_count == 0) & ((locate_add_detail.method=='WiFi') | (locate_add_detail.method=='Wifi'))])))
                    list_methods.append('MSA'+': '+str(len(locate_add_detail[locate_add_detail.method=='MSA'])))


                    msb = folium.FeatureGroup(name=list_methods[0],show=False)
                    wifi= folium.FeatureGroup(name=list_methods[1],show=False)
                    wifi_cached=folium.FeatureGroup(name=list_methods[2],show=False)
                    msa = folium.FeatureGroup(name=list_methods[3],show=False)

                    msb_bubble = folium.FeatureGroup(name='AccuracyBubble: MSB',show=False)
                    wifi_bubble = folium.FeatureGroup(name='AccuracyBubble: WiFi',show=False)
                    wifi_cached_bubble=folium.FeatureGroup(name='AccuracyBubble: WiFi_Cached',show=False)
                    msa_bubble = folium.FeatureGroup(name='AccuracyBubble: MSA',show=False)

                    directed_line=folium.FeatureGroup(name='Show directions',show=False)
                    minimap = plugins.MiniMap()
                    fullscreen=plugins.Fullscreen(position='topright',title='Expand me',title_cancel='Exit me',force_separate_button=True)

                    df_msb=locate_add_detail[locate_add_detail.method=='MSB'].reset_index()
                    df_wifi=locate_add_detail[(locate_add_detail.ap_count != 0) & (locate_add_detail.method=='WiFi')].reset_index()
                    df_wifi_cached=locate_add_detail[(locate_add_detail.ap_count == 0) & ((locate_add_detail.method=='WiFi') | (locate_add_detail.method=='Wifi'))].reset_index()
                    df_msa=locate_add_detail[locate_add_detail.method=='MSA'].reset_index()

                    df_msb_locationlist = df_msb[df_msb.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_wifi_locationlist = df_wifi[df_wifi.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_wifi_cached_locationlist = df_wifi_cached[df_wifi_cached.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    df_msa_locationlist = df_msa[df_msa.address!='no_location'][['latitude', 'longitude']].values.tolist()
                    #df_latlongs=locate_add_detail[['latitude', 'longitude']].values.tolist()

                    #Marker:
                    #MSB
                    for point in range(0, len(df_msb_locationlist)):
                        folium.Marker(df_msb_locationlist[point],tooltip=df_msb['accuracy'][point],icon=folium.Icon(color='blue', icon_color='white', icon='globe', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msb['accuracy'][point]),str(df_msb['ttf'][point]),df_msb['method'][point],str(df_msb['time'][point])[:19],df_msb['reason'][point],df_msb['address'][point],df_msb['latitude'][point],df_msb['longitude'][point],df_msb['latitude'][point],df_msb['longitude'][point])).add_to(msb)

                    #WIFI
                    for point in range(0, len(df_wifi_locationlist)):
                        folium.Marker(df_wifi_locationlist[point],tooltip=df_wifi['accuracy'][point],icon=folium.Icon(color='gray', icon_color='white', icon='wifi', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Signal Strength: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi['accuracy'][point],df_wifi['ttf'][point],df_wifi['method'][point],df_wifi['ap_count'][point],df_wifi['ap_strength'][point],str(df_wifi['time'][point])[:19],df_wifi['reason'][point],df_wifi['address'][point],df_wifi['latitude'][point],df_wifi['longitude'][point],df_wifi['latitude'][point],df_wifi['longitude'][point])).add_to(wifi)

                    #WiFi_Cached
                    for point in range(0, len(df_wifi_cached_locationlist)):
                        folium.Marker(df_wifi_cached_locationlist[point],tooltip=df_wifi_cached['accuracy'][point],icon=folium.Icon(color='lightgray', icon_color='white', icon='wifi', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi_cached['accuracy'][point],df_wifi_cached['ttf'][point],df_wifi_cached['method'][point],df_wifi_cached['ap_count'][point],str(df_wifi_cached['time'][point])[:19],df_wifi_cached['reason'][point],df_wifi_cached['address'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point])).add_to(wifi_cached)

                    #MSA
                    for point in range(0, len(df_msa_locationlist)):
                        folium.Marker(df_msa_locationlist[point],tooltip=df_msa['accuracy'][point],icon=folium.Icon(color='orange', icon_color='white', icon='phone', angle=0, prefix='fa'),popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msa['accuracy'][point]),str(df_msa['ttf'][point]),df_msa['method'][point],str(df_msa['time'][point])[:19],df_msa['reason'][point],df_msa['address'][point],df_msa['latitude'][point],df_msa['longitude'][point],df_msa['latitude'][point],df_msa['longitude'][point])).add_to(msa)

                    #BubbleChart
                    for point in range(0, len(df_msb_locationlist)):
                        folium.Circle(df_msb_locationlist[point],tooltip=df_msb['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msb['accuracy'][point]),str(df_msb['ttf'][point]),df_msb['method'][point],str(df_msb['time'][point])[:19],df_msb['reason'][point],df_msb['address'][point],df_msb['latitude'][point],df_msb['longitude'][point],df_msb['latitude'][point],df_msb['longitude'][point]),radius=float(df_msb['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(msb_bubble)

                    for point in range(0, len(df_wifi_locationlist)):
                        folium.Circle(df_wifi_locationlist[point],tooltip=df_wifi['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br><b>Signal Strength: </b>%s<br></br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi['accuracy'][point],df_wifi['ttf'][point],df_wifi['method'][point],df_wifi['ap_count'][point],df_wifi['ap_strength'][point],str(df_wifi['time'][point])[:19],df_wifi['reason'][point],df_wifi['address'][point],df_wifi['latitude'][point],df_wifi['longitude'][point],df_wifi['latitude'][point],df_wifi['longitude'][point]),radius=float(df_wifi['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(wifi_bubble)

                    for point in range(0, len(df_wifi_cached_locationlist)):
                        folium.Circle(df_wifi_cached_locationlist[point],tooltip=df_wifi_cached['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Access Points: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(df_wifi_cached['accuracy'][point],df_wifi_cached['ttf'][point],df_wifi_cached['method'][point],df_wifi_cached['ap_count'][point],str(df_wifi_cached['time'][point])[:19],df_wifi_cached['reason'][point],df_wifi_cached['address'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point],df_wifi_cached['latitude'][point],df_wifi_cached['longitude'][point]),radius=float(df_wifi_cached['accuracy'][point])*.5,color='crimson',fill=True,fill_color='crimson').add_to(wifi_cached_bubble)

                    for point in range(0, len(df_msa_locationlist)):
                        folium.Circle(df_msa_locationlist[point],tooltip=df_msa['accuracy'][point],popup="<b>Accuracy: </b>%s<br></br><b>ttf: </b>%s<br></br><b>Method: </b>%s<br></br><b>Time: </b>%s<br></br><b>Reason: </b>%s<br></br><b>Address: </b>%s<br></br><b>lat/long: </b>(%s,%s)<a href=http://maps.google.com/maps?q=%s,%s target=_blank title='Open Google Maps for this lat/long'>GMaps</a>"%(str(df_msa['accuracy'][point]),str(df_msa['ttf'][point]),df_msa['method'][point],str(df_msa['time'][point])[:19],df_msa['reason'][point],df_msa['address'][point],df_msa['latitude'][point],df_msa['longitude'][point],df_msa['latitude'][point],df_msa['longitude'][point]),radius=float(df_msa['accuracy'][point]),color='crimson',fill=True,fill_color='crimson').add_to(msa_bubble)

                    #Adding lines
                    for point in range(0, (len(df_latlongs)-1)):
                        folium.PolyLine(locations=[df_latlongs[point],df_latlongs[point+1]], color='orange').add_to(directed_line)



                    #Adding Arrows
                    directcall=[]
                    final_combined_arrows= []
                    for point in range(0, (len(df_latlongs)-1)):
                        directcall.append("get_arrows(locations=[df_latlongs["+str(point)+"],df_latlongs["+str(point+1)+"]], n_arrows=3)")
                        final_combined_arrows.append(eval(directcall[point]))

                    for main in final_combined_arrows:
                        for m in main:
                            (m.add_to(directed_line))


                    #folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(msb).add_child(wifi).add_child(msa).add_child(msb_bubble).add_child(wifi_bubble).add_child(msa_bubble).add_child(minimap))
                    folium.LayerControl(collapsed=False).add_to(basemap.add_child(htmap).add_child(msb).add_child(wifi).add_child(wifi_cached).add_child(msa).add_child(msb_bubble).add_child(wifi_bubble).add_child(wifi_cached_bubble).add_child(msa_bubble).add_child(directed_line).add_child(minimap).add_child(fullscreen).add_child(measure_control).add_child(mouse_position))
                    basemap.fit_bounds(htmap.get_bounds())
                    basemap.save('downloads/'+'Maps_'+output_file+'.htm')
                    end_time = timedelta(seconds=round(time.time() - start_time))
                    print(time.asctime(time.localtime())+":","Execution took: %s secs (Wall clock time)" % end_time,flush=True)
                except Exception as e:
                    print(time.asctime(time.localtime())+":",'\n****Error Thown****',flush=True)
                    print(time.asctime(time.localtime())+":",'--->',str(e),flush=True)
                    return '''<!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    <head>
                    <body>
                    <h1>****Error: {}****</h1>
                      <h2>Check the server logs</h2>
                      <h3>Contact: Mantej Singh (mantej.dhanjal@verizonwireless.com) or Priten Vora (priten.vora@verizonwireless.com)</h3>
                      <br>
                      <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                      </head>
                    </body>
                      '''.format(str(e))


                #return "Page submitted"
                return '''
                            <!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    </head>
                    <body>

                   <center> 
                    <h1>User MDN: {}</h1>
                    <h2>Gizmo MDN: {}</h2>
                    <br>
                    <h2>Total Records: {}</h2>
                    <h2>Total Null Locates: {}</h2>
                    <h2>Total WiFi MACs: {}</h2>
                      <h2>Total Days: {}</h2>
                      <h2>Total Processing Time: {}</h2>
                    <!-- Download your data->>. <a href="/getCSV">Click me.</a>-->
                    <a href="/getCSV"><button class="btn"><i class="fa fa-file-excel-o"></i> Download (xlsx)</button></a>
                    <!-- <a href="/getMAPS"><button class="btn"><i class="fa fa-map-marker"></i> Download (maps)</button></a>-->
                    <a href="/getZip"><button class="btn"><i class="fa fa-archive"></i> Download Zip (xlsx+maps)</button></a>
                                <br><br>
                    <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                    <!--<a href="session['devices']"><button class="btn"><i class="fa fa-list-ol"></i> Device</button></a>-->
                    <br><br>
                    <!--<iframe src="../downloads/Maps_9088001475_final_findings.htm" width=100% height=1000></iframe>-->
                    </body></html>'''.format(phone_mdn,device_mdn, len(samplePhoneGizmo_df),deleted_rows,total_macs,str(datetime.datetime.strptime(end_date,"%m-%d-%Y") - datetime.datetime.strptime(start_date,"%m-%d-%Y")),end_time)
            else:
                return '''<!-- Add icon library -->
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <style>
                    .btn {{
                      background-color: DodgerBlue;
                      border: none;
                      color: white;
                      padding: 12px 30px;
                      cursor: pointer;
                      font-size: 20px;
                    }}

                    /* Darker background on mouse-over */
                    .btn:hover {{
                      background-color: RoyalBlue;
                    }}
                    </style>
                    <head>
                    <body>
                    <h1>****Error: {}****</h1>
                      <h2>Please Choose an option from previous page</h2>
                      <br>
                      <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
                      </head>
                    </body>
                      '''.format(str(e))
    except Exception as e:
            print(time.asctime(time.localtime())+":",'\n****Error Thown****',flush=True)
            print(time.asctime(time.localtime())+":",'--->',str(e),flush=True)
            return '''<!-- Add icon library -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <style>
            .btn {{
              background-color: DodgerBlue;
              border: none;
              color: white;
              padding: 12px 30px;
              cursor: pointer;
              font-size: 20px;
            }}

            /* Darker background on mouse-over */
            .btn:hover {{
              background-color: RoyalBlue;
            }}
            </style>
            <head>
            <body>
            <h1>****Error: {}****</h1>
              <h2><u>Solution:</u> Kinldy choose an option from previous page :)</h2>
              <br>
              <a href="/"><button class="btn"><i class="fa fa-home"></i> Home </button></a>
              </head>
            </body>
              '''.format(str(e))


@app.route("/getZip")
def getZip():
    try:
        phone_mdn=session.get('phone_mdn')
        output_file_xlsx=session.get("output_file_xlsx")
        output_file_xlsx='downloads/'+output_file_xlsx
        output_file=session.get("output_file")
        output_file='downloads/'+'Maps_'+output_file+'.htm'
        zipObj = ZipFile('downloads/'+phone_mdn+'.zip', 'w')
        output_file_zip=phone_mdn+'.zip'
        print("\n\n File names:",output_file_xlsx,"  ",output_file,"\n\n" ,flush=True)
        zipObj.write(output_file)
        zipObj.write(output_file_xlsx)
        # close the Zip File
        zipObj.close()
        return send_file('downloads/'+ output_file_zip, attachment_filename=output_file_zip,as_attachment=True,mimetype='application/zip')
		#send_file('downloads/'+'My_Maps_'+output_file+'.htm')#
    except Exception as e:
        return str(e)


@app.route("/getCSV")
def getCSV():
    try:
        output_file_xlsx=session.get("output_file_xlsx")
        return send_file('downloads/'+ output_file_xlsx, attachment_filename=output_file_xlsx,as_attachment=True,mimetype='text/csv')
		#send_file('downloads/'+'My_Maps_'+output_file+'.htm')#
    except Exception as e:
        return str(e)

    
@app.route("/getgeoCSV")
def getgeoCSV():
    try:
        geo_output_file_xlsx=session.get("geo_output_file_xlsx")
        return send_file('downloads/'+ geo_output_file_xlsx, attachment_filename=geo_output_file_xlsx,as_attachment=True,mimetype='text/csv')
    except Exception as e:
        return str(e)

@app.route("/getgeoZip")
def getgeoZip():
    try:
        phone_mdn=session.get('phone_mdn')
        geo_output_file_xlsx=session.get("geo_output_file_xlsx")
        geo_output_file_xlsx='downloads/'+geo_output_file_xlsx
        geo_output_file=session.get("geo_output_file")
        geo_output_file='downloads/'+'Maps_'+geo_output_file+'.htm'
        zipObj = ZipFile('downloads/'+phone_mdn+'.zip', 'w')
        output_file_zip=phone_mdn+'.zip'
        print("\n\n File names:",geo_output_file_xlsx,"  ",geo_output_file,"\n\n" ,flush=True)
        zipObj.write(geo_output_file)
        zipObj.write(geo_output_file_xlsx)
        # close the Zip File
        zipObj.close()
        return send_file('downloads/'+ output_file_zip, attachment_filename=output_file_zip,as_attachment=True,mimetype='application/zip')
    except Exception as e:
        return str(e)

'''@app.route("/getMAPS")		
def getMAPS():
    try:
        output_file=session.get("output_file")
        return send_file('downloads/'+'Maps_'+output_file+'.htm',attachment_filename='Maps_'+output_file+'.htm',as_attachment=True,mimetype='text/html')#
        print(output_file_xlsx,output_file,flush=True)
    except Exception as e:
        return str(e)
'''
if __name__ == '__main__':
    #app.run(debug=True,host="0.0.0.0", port=80)
    app.run(debug=True)
    #app.run(debug=True,host="0.0.0.0", port=8080, ssl_context=('/home/ec2-user/WebSite/letsecrypt/0000_csr-certbot.pem', '/home/ec2-user/WebSite/letsecrypt/0000_key-certbot.pem'))
